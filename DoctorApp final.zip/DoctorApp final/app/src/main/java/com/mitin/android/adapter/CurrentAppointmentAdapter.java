package com.mitin.android.adapter;

import android.content.Context;
import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.mitin.android.Doctor.Detail;
import com.mitin.android.R;
import com.mitin.android.helper.AppConst;
import com.mitin.android.model.AppointmentPojo;
import com.mitin.android.view.CropSquareTransformation;
import com.github.curioustechizen.ago.RelativeTimeTextView;
import com.squareup.picasso.Picasso;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;


public class CurrentAppointmentAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private static final int TYPE_ITEM = 1;
    private List<AppointmentPojo> list;
    Context context;
    String TAG="CurrentAppointmentAdapter";
    SimpleDateFormat defaultfmt=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    SimpleDateFormat dtfmt=new SimpleDateFormat("dd MMM yyyy, hh:mm a");

    public CurrentAppointmentAdapter(List<AppointmentPojo> list, Context mcontext) {
        context = mcontext;
        this.list = list;
    }

    @Override
    public int getItemViewType(int position) {
        return TYPE_ITEM;
    }


    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.appointment_row, parent, false);
        return new ViewHolderPosts(view);
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {

        final AppointmentPojo model=list.get(position);
        final ViewHolderPosts itemview = (ViewHolderPosts) holder;

        itemview.tvname.setText(model.getName());
        String t=model.getAppointment_date()+" "+model.getAppointment_time();
        Date dt=null,curr=null;
        try {
            dt=defaultfmt.parse(t);
            itemview.tvtime.setText(dtfmt.format(dt));
//            itemview. tvtime.setText(""+AppConst.getLastSeenDate(t));
//            itemview.tvtime.setReferenceTime(dt.getTime());
            if(dt.before(new Date())){
                itemview.ll.setBackgroundColor(context.getResources().getColor(R.color.row));
            }else{
                itemview.ll.setBackgroundColor(context.getResources().getColor(android.R.color.transparent));
            }
        } catch (ParseException e) {
            e.printStackTrace();
        }

        String note=model.getNote();
        if(note!=null){
            if(note.trim().length()>0) {
                itemview.tvnote.setVisibility(View.VISIBLE);
                itemview.tvnote.setText(note);
            }else
                itemview.tvnote.setVisibility(View.GONE);
        }else{
            itemview.tvnote.setVisibility(View.GONE);
        }
        String pic=model.getPhoto();
        if(pic.trim().length()>0){
            Picasso.with(context)
                    .load(AppConst.profile_img_url + pic)
                    .transform(new CropSquareTransformation())
                    .placeholder(R.drawable.ic_user)
                    .error(R.drawable.ic_user)
                    .into(itemview.iv);
        }

        String status=model.getAppointment_status();
        itemview.tvstatus.setVisibility(View.VISIBLE);
        itemview.tvstatus.setText(status);
        if(status.equals("pending")){
            itemview.tvstatus.setTextColor(context.getResources().getColor(android.R.color.holo_blue_bright));
        }else if(status.equals("accepted")){
            itemview.tvstatus.setTextColor(context.getResources().getColor(android.R.color.holo_green_light));
        }else{
            itemview.tvstatus.setTextColor(context.getResources().getColor(android.R.color.holo_green_dark));
        }

        itemview.ll.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent it=new Intent(context, Detail.class);
                AppConst.selAppointment=model;
                context.startActivity(it);
            }
        });
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public int getItemCount() {

        return list.size();

    }

    public class ViewHolderPosts extends RecyclerView.ViewHolder {
        TextView tvname,tvnote,tvstatus;
        RelativeTimeTextView tvtime;
        ImageView iv;
        LinearLayout ll;

        public ViewHolderPosts(View itemView) {
            super(itemView);
            tvname = (TextView) itemView.findViewById(R.id.tvdrname);
            tvname.setTypeface(AppConst.font_regular(context));
            tvtime = (RelativeTimeTextView) itemView.findViewById(R.id.tvtime);
            tvtime.setTypeface(AppConst.font_regular(context));
            tvnote = (TextView) itemView.findViewById(R.id.tvnote);
            tvnote.setTypeface(AppConst.font_regular(context));
            tvstatus = (TextView) itemView.findViewById(R.id.tvstatus);
            tvstatus.setTypeface(AppConst.font_regular(context));
            iv = (ImageView) itemView.findViewById(R.id.ivdoctor);
            ll=(LinearLayout)itemView.findViewById(R.id.llappointment);
        }

    }

}
