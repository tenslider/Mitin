package com.mitin.android;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;
import com.mitin.android.adapter.MessageListAdapter;
import com.mitin.android.helper.AppConst;
import com.mitin.android.model.GetMessagePojo;
import com.mitin.android.model.M;
import com.mitin.android.model.Message;
import com.mitin.android.model.SearchUserResponse;
import com.mitin.android.model.SuccessPojo;
import com.mitin.android.sqlite.DatabaseHandler;
import com.mitin.android.view.ChatMessageReceived;
import com.mitin.android.webservice.MessageAPI;
import com.mitin.android.webservice.Service;

import java.util.ArrayList;
import java.util.List;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Response;

/**
 * Created by VBT-Android on 6/3/2017.
 */

public class FragMessageCompose extends Fragment implements ChatMessageReceived, View.OnClickListener {

    private String TAG = FragMessageCompose.class.getSimpleName();

    private Context mContext;
    
    private DatabaseHandler dbHandler;

    private RecyclerView recyclerView;
    private TextView tvNoRecords;

    private EditText etMessage;
    private ImageView ivSend;

    MyApplication myApp;

    private List<Message> messageList = new ArrayList<>();
    private MessageListAdapter messageListAdapter;

    private SearchUserResponse.User searchUser;

    private int page = 1;
    public static String ARG_SEARCH_USER = "SEARCH_USER";
    public static String ARG_SENDER_ID = "sender_id";
    static String ARG_SENDER_NAME = "sender_name";
    //private int senderId = 0;

    // TODO: Rename and change types and number of parameters
    public static FragMessageCompose newInstance(String param1) {
        FragMessageCompose fragment = new FragMessageCompose();
        Bundle args = new Bundle();
        args.putString(ARG_SEARCH_USER, param1);
        //args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    public static FragMessageCompose newInstance(int senderId,String name) {
        Log.d("chat:FragMessageCompose",senderId+" - "+name);
        FragMessageCompose fragment = new FragMessageCompose();
        Bundle args = new Bundle();
        args.putInt(ARG_SENDER_ID, senderId);
        args.putString(ARG_SENDER_NAME, name);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mContext = getActivity();
        myApp = (MyApplication) getActivity().getApplication();
        dbHandler = new DatabaseHandler(mContext);

        if (getArguments() != null) {

            if(getArguments().containsKey(ARG_SEARCH_USER)) {
                searchUser = new Gson().fromJson(getArguments().getString(ARG_SEARCH_USER), SearchUserResponse.User.class);
            }
            if(getArguments().containsKey(ARG_SENDER_ID)) {

                int senderId = getArguments().getInt(ARG_SENDER_ID);
                String sendername = getArguments().getString(ARG_SENDER_NAME);

                searchUser = new SearchUserResponse.User();

                searchUser.setId(senderId);
                searchUser.setName(sendername);
                searchUser.setPhoto("");
            }
        }
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.frag_message_compose, container, false);
        MainActivity.tvheading.setVisibility(View.VISIBLE);
        MainActivity.ivheading.setVisibility(View.GONE);
        MainActivity.tvheading.setText(searchUser.getName());
        init(view);

        myApp.setInChatList(true);
        myApp.setChatUserId(searchUser.getId());

        return view;
    }

    @Override
    public void onDestroyView() {

        myApp.setInChatList(false);
        myApp.setChatUserId(0);
        MainActivity.tvheading.setVisibility(View.GONE);
        MainActivity.ivheading.setVisibility(View.VISIBLE);
        super.onDestroyView();
    }

    private void init(View view)
    {
        try
        {
            etMessage = (EditText) view.findViewById(R.id.etMessage);
            etMessage.setTypeface(AppConst.font_regular(mContext));
            ivSend = (ImageView) view.findViewById(R.id.ivSend);

            recyclerView = (RecyclerView) view.findViewById(R.id.recyclerView);
            tvNoRecords = (TextView) view.findViewById(R.id.tvNoRecords);
            tvNoRecords.setTypeface(AppConst.font_regular(mContext));

            recyclerView.setHasFixedSize(true);
            recyclerView.setLayoutManager(new LinearLayoutManager(mContext));

            ivSend.setOnClickListener(this);

            messageListAdapter = new MessageListAdapter(mContext, messageList, recyclerView);
            recyclerView.setAdapter(messageListAdapter);

            //Load Messages

            messageList.addAll(dbHandler.getAllMessages(searchUser.getId()));
            Log.d("chat:"+TAG,"msg list size:"+messageList.size());
            if(messageList != null && messageList.size() > 0)
            {
                messageListAdapter.notifyDataSetChanged();
                String messageTime = messageList.get(messageList.size()-1).getTime();
                doGetMessage(messageTime);
            }else{
                doGetMessage("");
            }


        }
        catch (Exception ex)
        {
            ex.printStackTrace();
        }
    }

    /*Set No Recods Found*/
    private void setNoRecords()
    {
        try
        {
            tvNoRecords.setVisibility(View.VISIBLE);
            recyclerView.setVisibility(View.GONE);
        }
        catch (Exception ex)
        {
            ex.printStackTrace();
        }
    }

    /*
    Load Fragment
    */
    private void loadFragment(Fragment fragment, String fragmentTag) {
        try {
            FragmentTransaction ft = getFragmentManager().beginTransaction();
            ft.replace(R.id.content_frame, fragment, fragmentTag);
            ft.addToBackStack(fragmentTag);
            ft.commit();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    private void doSendMessage() {
        String message = etMessage.getText().toString().trim();
        MessageAPI mAuthenticationAPI = Service.createService(mContext,MessageAPI.class);
        Call<SuccessPojo> call = mAuthenticationAPI.sendMessage(M.getID(mContext),searchUser.getId()+"",message,M.getRole(getActivity()));
        call.enqueue(new retrofit2.Callback<SuccessPojo>() {
            @Override
            public void onResponse(Call<SuccessPojo> call, Response<SuccessPojo> response) {
                Log.d("response:","data:"+response);
                if (response.isSuccessful()) {
                    SuccessPojo pojo=response.body();
                    if(pojo!=null){
                        if(pojo.getSuccess().equals("1")){
                            Message message = new Message();
                            message.setMessage_id(pojo.getLastInsertedId());
                            message.setSender_id(M.getID(mContext));
                            message.setReceiver_id(searchUser.getId()+"");
                            message.setSender_name(M.getUsername(mContext));
                            message.setReceiver_name(searchUser.getName());
                            message.setSender_profile_pic(M.getPhoto(mContext));
                            message.setReceiver_profile_pic(searchUser.getPhoto());
                            message.setMessage(etMessage.getText().toString().trim());
                            message.setSend_by(M.getRole(getActivity()));
                            message.setTime(pojo.getTimestamp());

                            dbHandler.addMessage(message);

                            etMessage.setText("");

                            if(messageList.size()>0)
                                getLatestMessageForDB(messageList.get(messageList.size()-1).getMessage_id()+"");
                            else
                                getLatestMessageForDB("0");
                        }
                    }

                } else {
                    int statusCode = response.code();
                    ResponseBody errorBody = response.errorBody();
                    Log.d(TAG,"error:"+statusCode+" "+errorBody);
                }

            }

            @Override
            public void onFailure(Call<SuccessPojo> call, Throwable t) {
                Log.d("response:","fail:"+t.getMessage());
            }
        });
    }

    private void doGetMessage(String timeStamp) {
        Log.d(TAG,"doGetMessage "+searchUser.getId()+" "+M.getID(mContext)+" "+page+" "+timeStamp+" "+M.getRole(mContext));
        MessageAPI mAuthenticationAPI = Service.createService(mContext,MessageAPI.class);
        Call<GetMessagePojo> call = mAuthenticationAPI.getMessages(searchUser.getId()+"",M.getID(mContext),page+"",timeStamp,M.getRole(mContext));
        call.enqueue(new retrofit2.Callback<GetMessagePojo>() {
            @Override
            public void onResponse(Call<GetMessagePojo> call, Response<GetMessagePojo> response) {
                Log.d(TAG,"response get msg:"+response);
                if (response.isSuccessful()) {
                    GetMessagePojo dataList=response.body();
                    if (dataList!= null) {

                        if(dataList.getMessages().size() > 0)
                        {
                            for(int i=0;i<dataList.getMessages().size();i++)
                            {
                                Message data = dataList.getMessages().get(i);

                                Message message = new Message();
                                Log.d(TAG,"server mid"+data.getMessage_id()+" "+data.getMessage());
                                message.setMessage_id(data.getMessage_id());
                                message.setSender_id(data.getSender_id());
                                message.setReceiver_id(data.getReceiver_id());
                                message.setSender_name(data.getSender_name());
                                message.setReceiver_name(data.getReceiver_name());
                                message.setSender_profile_pic(data.getSender_profile_pic());
                                message.setReceiver_profile_pic(data.getReceiver_profile_pic());
                                message.setMessage(data.getMessage());
                                message.setSend_by(data.getSend_by());
                                message.setTime(data.getTime());

                                dbHandler.addMessage(message);
                            }
                            if(messageList.size()>0)
                                getLatestMessageForDB(messageList.get(messageList.size()-1).getMessage_id());
                            else
                                getLatestMessageForDB("0");
                        }
                    }

                } else {
                    int statusCode = response.code();
                    ResponseBody errorBody = response.errorBody();
                    Log.d(TAG,"error:"+statusCode+" "+errorBody);
                }

            }

            @Override
            public void onFailure(Call<GetMessagePojo> call, Throwable t) {
                Log.d(TAG,"fail:"+t.getMessage());
            }
        });
    }


    @Override
    public void onChatMessageReceived() {
        try
        {
            String message_id = messageList.get(messageList.size()-1).getMessage_id();

            getLatestMessageForDB(message_id);

            /*
            List<Message> newMessageList = dbHandler.getAllMessages(searchUser.getId(), message_id);

            messageList.addAll(newMessageList);

            messageListAdapter.notifyItemInserted(messageList.size()-1);
            */
        }
        catch (Exception ex)
        {
            ex.printStackTrace();
        }
    }


    private void getLatestMessageForDB(String messageId)
    {
        try
        {
            messageList.addAll(dbHandler.getAllMessages(searchUser.getId(),Long.parseLong( messageId)));
            messageListAdapter.notifyDataSetChanged();

            recyclerView.smoothScrollToPosition(messageList.size() - 1);
        }
        catch (Exception ex)
        {
            ex.printStackTrace();
        }
    }

    @Override
    public void onClick(View v) {
        hideSoftKeyboard(mContext, v);
        switch (v.getId()) {

            case R.id.ivSend:
                String message = etMessage.getText().toString().trim();
                if(message.trim().length()>0)
                    doSendMessage();
                break;

            default:
                break;
        }
    }

    // Hide keyboard
    public static void hideSoftKeyboard(Context context, View view) {
        InputMethodManager inputMethodManager = (InputMethodManager)
                context.getSystemService(Activity.INPUT_METHOD_SERVICE);
        if (inputMethodManager != null && inputMethodManager.isActive()) {
            if(view != null)
                inputMethodManager.hideSoftInputFromWindow(view.getWindowToken(), 0);
        }
    }
}
