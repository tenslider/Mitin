package com.mitin.android.model;


import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class User {

    private String id;
    private String doctor_name;
    private String period;
    private String address;
    private String clinic_name;
    private String clinic_phone;
    private String personal_phone;
    private String about;
    private String gcm_token;
    private String latitude;
    private String longitude;
    private String education_details;
    private String cost_with_ins;
    private String cost_without_ins;
    private String type;
    private String lawyer_type;
    private String office_address;
    private String experience_years;
    private String how_long_in_business;
    private String wash_price;
    private String manicure_pedicure_price;
    private List<DepartmentPojo> department = null;
    private List<Duty_timing> duty_timing = null;
    private List<Clinic_image> clinic_images = null;
    private List<Rating> ratings = null;
    private Integer overall_rating;

    private String name;
    private String email;
    private String gender;
    private String photo,city,mobile_no;
    private String login_type;
    String insurance_name,date_of_birth,cedula,policy_number;
    private String availbility_status,doctor_image;//for mitin
    String blood_type,height,weight,current_health_condition,chronic_condition;

    public String getId() {
        return id;
    }

    public String getDoctor_name() {
        return doctor_name;
    }

    public String getPeriod() {
        return period;
    }

    public String getAddress() {
        return address;
    }

    public String getClinic_name() {
        return clinic_name;
    }

    public String getClinic_phone() {
        return clinic_phone;
    }

    public String getPersonal_phone() {
        return personal_phone;
    }

    public String getAbout() {
        return about;
    }

    public String getGcm_token() {
        return gcm_token;
    }

    public String getLatitude() {
        return latitude;
    }

    public String getLongitude() {
        return longitude;
    }

    public String getEducation_details() {
        return education_details;
    }

    public String getCost_with_ins() {
        return cost_with_ins;
    }

    public String getCost_without_ins() {
        return cost_without_ins;
    }

    public String getType() {
        return type;
    }

    public String getLawyer_type() {
        return lawyer_type;
    }

    public String getOffice_address() {
        return office_address;
    }

    public String getExperience_years() {
        return experience_years;
    }

    public String getHow_long_in_business() {
        return how_long_in_business;
    }

    public String getWash_price() {
        return wash_price;
    }

    public String getManicure_pedicure_price() {
        return manicure_pedicure_price;
    }

    public List<DepartmentPojo> getDepartment() {
        return department;
    }

    public List<Duty_timing> getDuty_timing() {
        return duty_timing;
    }

    public List<Clinic_image> getClinic_images() {
        return clinic_images;
    }

    public List<Rating> getRatings() {
        return ratings;
    }

    public Integer getOverall_rating() {
        return overall_rating;
    }

    public String getName() {
        return name;
    }

    public String getEmail() {
        return email;
    }

    public String getGender() {
        return gender;
    }

    public String getPhoto() {
        return photo;
    }

    public String getCity() {
        return city;
    }

    public String getMobile_no() {
        return mobile_no;
    }

    public String getLogin_type() {
        return login_type;
    }

    public String getInsurance_name() {
        return insurance_name;
    }

    public String getDate_of_birth() {
        return date_of_birth;
    }

    public String getCedula() {
        return cedula;
    }

    public String getPolicy_number() {
        return policy_number;
    }

    public String getAvailbility_status() {
        return availbility_status;
    }

    public String getDoctor_image() {
        return doctor_image;
    }

    public String getBlood_type() {
        return blood_type;
    }

    public String getHeight() {
        return height;
    }

    public String getWeight() {
        return weight;
    }

    public String getCurrent_health_condition() {
        return current_health_condition;
    }

    public String getChronic_condition() {
        return chronic_condition;
    }
}
