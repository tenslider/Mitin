package com.mitin.android.Doctor;

import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.mitin.android.R;
import com.mitin.android.adapter.CurrentAppointmentAdapter;
import com.mitin.android.helper.AppConst;
import com.mitin.android.model.AppointmentPojo;
import com.mitin.android.model.M;
import com.mitin.android.webservice.DoctorAPI;
import com.mitin.android.webservice.Service;

import java.util.List;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class CurrentFragment extends Fragment {

    View view;
    RecyclerView rv;
    TextView tvnodata;
    Context context;
    String TAG="CurrentFragment";

    CurrentAppointmentAdapter cadapter;

    public CurrentFragment() {

    }

    public static CurrentFragment newInstance() {
        CurrentFragment fragment = new CurrentFragment();
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        view= inflater.inflate(R.layout.fragment_history, container, false);
        context=getActivity();
        tvnodata=(TextView)view.findViewById(R.id.tvnodata);
        tvnodata.setTypeface(AppConst.font_light(context));
        rv=(RecyclerView)view.findViewById(R.id.rv);
        rv.setLayoutManager(new LinearLayoutManager(context));
        rv.setHasFixedSize(true);
        getCurrentData();
        return view;
    }

    private void getCurrentData(){
        M.showLoadingDialog(context);
        DoctorAPI mAuthenticationAPI = Service.createService(context,DoctorAPI.class);
        Call<List<AppointmentPojo>> call = mAuthenticationAPI.getTodays(M.getID(context));
        call.enqueue(new Callback<List<AppointmentPojo>>() {
            @Override
            public void onResponse(Call<List<AppointmentPojo>> call, Response<List<AppointmentPojo>> response) {
                Log.d("response:","data:"+response);
                if (response.isSuccessful()) {
                    List<AppointmentPojo> pojo=response.body();
                    if(pojo!=null && pojo.size()>0){
                        rv.setVisibility(View.VISIBLE);
                        tvnodata.setVisibility(View.GONE);
                        cadapter=new CurrentAppointmentAdapter(pojo,context);
                        rv.setAdapter(cadapter);
                    }else{
                        rv.setVisibility(View.GONE);
                        tvnodata.setVisibility(View.VISIBLE);
                    }

                } else {
                    int statusCode = response.code();
                    ResponseBody errorBody = response.errorBody();
                    Log.d(TAG,"error:"+statusCode+" "+errorBody);
                }
                M.hideLoadingDialog();
            }

            @Override
            public void onFailure(Call<List<AppointmentPojo>> call, Throwable t) {
                Log.d("response:","fail:"+t.getMessage());
                M.hideLoadingDialog();
            }
        });
    }
}
