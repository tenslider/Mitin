package com.mitin.android.webservice;

import com.mitin.android.model.AppointmentPojo;
import com.mitin.android.model.SuccessPojo;

import java.util.List;

import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.POST;

/**
 * Created by SWIFT-3 on 17/07/17.
 */

public interface DoctorAPI {

    @POST("doctor_edit_profile.php")
    Call<SuccessPojo> editProfile(@Body RequestBody body);

    @FormUrlEncoded
    @POST("upcoming_appointment.php")
    Call<List<AppointmentPojo>> getUpcoming(
            @Field("doctor_id") String doctor_id
    );

    @FormUrlEncoded
    @POST("todays_appointment.php")
    Call<List<AppointmentPojo>> getTodays(
            @Field("doctor_id") String doctor_id
    );

    @FormUrlEncoded
    @POST("past_appointment.php")
    Call<List<AppointmentPojo>> getHistory(
            @Field("doctor_id") String doctor_id
    );

    @FormUrlEncoded
    @POST("appointment_status_update.php")
    Call<SuccessPojo> updateStatus(
            @Field("doctor_id") String doctor_id,
            @Field("appointment_id") String appointment_id,
            @Field("status") String status,
            @Field("diagnosis") String diagnosis,
            @Field("prognosis") String prognosis,
            @Field("prescription") String prescription,
            @Field("type") String type
    );

    @FormUrlEncoded
    @POST("delete_clinic_image.php")
    Call<SuccessPojo> deleteImage(
            @Field("clinic_img_id") String clinic_img_id);

    @FormUrlEncoded
    @POST("update_doc_availibility.php")
    Call<SuccessPojo> updateDrStaus(
            @Field("availbility_status") String availbility_status,
            @Field("doctor_id") String doctor_id);


}
