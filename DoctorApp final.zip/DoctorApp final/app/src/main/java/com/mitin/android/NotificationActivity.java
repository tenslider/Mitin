package com.mitin.android;

import android.content.Context;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

import com.mitin.android.adapter.NotificationAdapter;
import com.mitin.android.helper.AppConst;
import com.mitin.android.model.M;
import com.mitin.android.model.NotificationPojo;
import com.mitin.android.webservice.APIAuthentication;
import com.mitin.android.webservice.Service;

import java.util.List;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Response;

public class NotificationActivity extends AppCompatActivity {

    RecyclerView rv;
    TextView tv;
    Context context;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fragment_notification);
        getSupportActionBar().setHomeButtonEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        context=NotificationActivity.this;

        tv=(TextView)findViewById(R.id.tv);
        tv.setTypeface(AppConst.font_regular(context));
        tv.setVisibility(View.GONE);
        rv=(RecyclerView)findViewById(R.id.rv);
        rv.setLayoutManager(new LinearLayoutManager(context));
        rv.setHasFixedSize(true);

        getData();
    }

    private void getData() {

        M.showLoadingDialog(context);
        APIAuthentication mAuthenticationAPI = Service.createService(context,APIAuthentication.class);
        Call<List<NotificationPojo>> call = mAuthenticationAPI.getData(M.getID(context),M.getRole(context));
        call.enqueue(new retrofit2.Callback<List<NotificationPojo>>() {
            @Override
            public void onResponse(Call<List<NotificationPojo>> call, Response<List<NotificationPojo>> response) {
                Log.d("response:","data:"+response);
                if (response.isSuccessful()) {
                    List<NotificationPojo> pojo = response.body();
                    if(pojo.size()>0){
                        NotificationAdapter adapter=new NotificationAdapter(pojo,context);
                        rv.setAdapter(adapter);
                    }
                    M.hideLoadingDialog();
                } else {
                    int statusCode = response.code();
                    M.hideLoadingDialog();
                    ResponseBody errorBody = response.errorBody();
                }
            }

            @Override
            public void onFailure(Call<List<NotificationPojo>> call, Throwable t) {
                Log.d("response:","fail:"+t.getMessage());
                M.hideLoadingDialog();
                // handle execution failures like no internet connectivity
            }
        });
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if(item.getItemId()==android.R.id.home)
            onBackPressed();
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }
}
