package com.mitin.android.model;

import java.util.HashMap;
import java.util.Map;

public class Message {

    private String message_id;
    private String receiver_id;
    private String sender_id;
    private String sender_name;
    private String sender_profile_pic;
    private String receiver_name;
    private String receiver_profile_pic;
    private String message;
    private String send_by;
    private String type;
    private String time;
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    public String getMessage_id() {
        return message_id;
    }

    public void setMessage_id(String message_id) {
        this.message_id = message_id;
    }

    public String getReceiver_id() {
        return receiver_id;
    }

    public void setReceiver_id(String receiver_id) {
        this.receiver_id = receiver_id;
    }

    public String getSender_id() {
        return sender_id;
    }

    public void setSender_id(String sender_id) {
        this.sender_id = sender_id;
    }

    public String getSender_name() {
        return sender_name;
    }

    public void setSender_name(String sender_name) {
        this.sender_name = sender_name;
    }

    public String getSender_profile_pic() {
        return sender_profile_pic;
    }

    public void setSender_profile_pic(String sender_profile_pic) {
        this.sender_profile_pic = sender_profile_pic;
    }

    public String getReceiver_name() {
        return receiver_name;
    }

    public void setReceiver_name(String receiver_name) {
        this.receiver_name = receiver_name;
    }

    public String getReceiver_profile_pic() {
        return receiver_profile_pic;
    }

    public void setReceiver_profile_pic(String receiver_profile_pic) {
        this.receiver_profile_pic = receiver_profile_pic;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getSend_by() {
        return send_by;
    }

    public void setSend_by(String send_by) {
        this.send_by = send_by;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}
