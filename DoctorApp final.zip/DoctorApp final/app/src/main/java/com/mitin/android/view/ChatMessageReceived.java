package com.mitin.android.view;

/**
 * Created by VBT-Android on 6/27/2017.
 */

public interface ChatMessageReceived {
    public void onChatMessageReceived();
}
