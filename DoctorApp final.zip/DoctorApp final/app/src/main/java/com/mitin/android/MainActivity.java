package com.mitin.android;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.IntentSender;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.ActionBarDrawerToggle;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.content.ContextCompat;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.SwitchCompat;
import android.support.v7.widget.Toolbar;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.util.Log;
import android.widget.Toast;

import com.mitin.android.Doctor.AppointmentFragment;
import com.mitin.android.Doctor.DoctorProfile;
import com.mitin.android.Doctor.UpcomingFragment;
import com.mitin.android.adapter.DrawerAdapter;
import com.mitin.android.helper.AppConst;
import com.mitin.android.helper.ConnectionDetector;
import com.mitin.android.model.DrawerPojo;
import com.mitin.android.model.M;
import com.mitin.android.model.Message;
import com.mitin.android.model.SuccessPojo;
import com.mitin.android.sqlite.DatabaseHandler;
import com.mitin.android.util.GPSTracker;
import com.mitin.android.view.ChatMessageReceived;
import com.mitin.android.view.CropSquareTransformation;
import com.mitin.android.webservice.APIAuthentication;
import com.mitin.android.webservice.DoctorAPI;
import com.mitin.android.webservice.Service;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.PendingResult;
import com.google.android.gms.common.api.ResultCallback;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.LocationSettingsRequest;
import com.google.android.gms.location.LocationSettingsResult;
import com.google.android.gms.location.LocationSettingsStatusCodes;
import com.google.firebase.iid.FirebaseInstanceId;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity implements GoogleApiClient.ConnectionCallbacks, GoogleApiClient.OnConnectionFailedListener, ResultCallback<LocationSettingsResult> {

    public static TextView tvheading;
    public static ImageView ivheading;
    private ListView mDrawerList;
    private DrawerLayout mDrawerLayout;
    private ActionBarDrawerToggle mDrawerToggle;
    private CharSequence mDrawerTitle;
    private CharSequence mTitle;
    int fragmentposition = 1;
    String TAG="MainActivity",userid;
    Context context;
    ArrayList<DrawerPojo> list = new ArrayList<>();
    String role,senderName="";
    protected GoogleApiClient mGoogleApiClient;
    private final int MY_PERMISSIONS_REQUEST_LOCATION = 3;
    int REQUEST_CHECK_SETTINGS = 100;
    protected LocationRequest locationRequest;
    ConnectionDetector connectionDetector;
    GPSTracker gpsTracker;
    SwitchCompat sw;
    TextView tvstatus;
    int senderId=0;
    private DatabaseHandler dbHandler ;
    private ChatMessageReceived chatMessageListener;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        context=MainActivity.this;
        userid= M.getID(MainActivity.this);
        role=M.getRole(context);
        if(role==null)
            role="";
        isStoragePermissionGranted();
        dbHandler = new DatabaseHandler(this);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        tvheading=(TextView)findViewById(R.id.tvheading);
        tvheading.setTypeface(AppConst.font_semibold(context));
        tvheading.setVisibility(View.GONE);
        ivheading=(ImageView)findViewById(R.id.ivheading);
        ivheading.setVisibility(View.VISIBLE);
        mDrawerLayout = (DrawerLayout) findViewById(R.id.drawer_layout);
        mTitle = mDrawerTitle = getTitle();
        mDrawerList = (ListView) findViewById(R.id.list_view);

        mDrawerLayout.setDrawerShadow(R.drawable.drawer_shadow,
                GravityCompat.START);

        View headerView = getLayoutInflater().inflate(
                R.layout.header_navigation_drawer, mDrawerList, false);

        ImageView iv = (ImageView) headerView.findViewById(R.id.image);
        TextView tvusername=(TextView)headerView.findViewById(R.id.tvusername);
        tvusername.setTypeface(AppConst.font_regular(context));
        TextView tvemail=(TextView)headerView.findViewById(R.id.tvemail);
        tvemail.setTypeface(AppConst.font_regular(context));
        TextView tvcity=(TextView)headerView.findViewById(R.id.tvcity);
        tvcity.setTypeface(AppConst.font_regular(context));
        sw=(SwitchCompat)headerView.findViewById(R.id.sw);
        tvstatus=(TextView)headerView.findViewById(R.id.tvstatus);
        tvstatus.setTypeface(AppConst.font_regular(context));
        tvusername.setText(M.getUsername(MainActivity.this));
        tvemail.setText(M.getEmail(MainActivity.this));
        String imgurl;
        if(!role.equalsIgnoreCase("patient")){
            sw.setVisibility(View.VISIBLE);
            tvstatus.setVisibility(View.VISIBLE);
            tvcity.setVisibility(View.GONE);
            imgurl=AppConst.doctor_img_url;
        }else {
            tvcity.setVisibility(View.VISIBLE);
            sw.setVisibility(View.GONE);
            tvstatus.setVisibility(View.GONE);
            tvcity.setText(M.getCity(MainActivity.this));
            imgurl=AppConst.profile_img_url;
        }
        String pic=M.getPhoto(MainActivity.this);
        if(pic==null)
            pic="";

        if(pic.trim().length()>0){

            Picasso.with(MainActivity.this)
                    .load(imgurl + pic)
                    .transform(new CropSquareTransformation())
                    .placeholder(R.drawable.ic_user)
                    .error(R.drawable.ic_user)
                    .into(iv);
        }
        if(M.getStatus(context)!=null) {
            tvstatus.setTag(M.getStatus(context));
            if (M.getStatus(context).equals("1")) {
                sw.setChecked(true);
                tvstatus.setText(getString(R.string.txt_avaliable));
            } else {
                sw.setChecked(false);
                tvstatus.setText(getString(R.string.txt_unavaliable));
            }
        }
        sw.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked){
                    tvstatus.setText(getString(R.string.txt_avaliable));
                    tvstatus.setTag("1");
                    updateStatus("1");
                }else{
                    tvstatus.setText(getString(R.string.txt_unavaliable));
                    tvstatus.setTag("0");
                    updateStatus("0");
                }
            }
        });
        ImageView ivdrawer=(ImageView)findViewById(R.id.ivdrawer);
        ivdrawer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mDrawerLayout.isDrawerOpen(Gravity.LEFT)) {
                    mDrawerLayout.closeDrawer(Gravity.LEFT);
                }
                else {
                    mDrawerLayout.openDrawer(Gravity.LEFT);
                }
            }
        });
        mDrawerList.addHeaderView(headerView);// Add header before adapter (for
        // pre-KitKat)
        mDrawerList.setAdapter(new DrawerAdapter(MainActivity.this,getDummyList()));
        mDrawerList.setOnItemClickListener(new DrawerItemClickListener());
//        int color = getResources().getColor(R.color.material_grey_100);
//        color = Color.argb(0xCD, Color.red(color), Color.green(color),
//                Color.blue(color));
//        mDrawerList.setBackgroundColor(color);
        mDrawerList.getLayoutParams().width = (int) getResources()
                .getDimension(R.dimen.drawer_width);

        mDrawerToggle = new ActionBarDrawerToggle(this, mDrawerLayout, R.drawable.menu,
                R.string.drawer_open, R.string.drawer_close) {
            public void onDrawerClosed(View view) {
                getSupportActionBar().setTitle(mTitle);
                invalidateOptionsMenu();
            }

            public void onDrawerOpened(View drawerView) {
                getSupportActionBar().setTitle(mDrawerTitle);
                invalidateOptionsMenu();
            }
        };
        mDrawerLayout.setDrawerListener(mDrawerToggle);

        if (getIntent().hasExtra(MyFirebaseMessagingService.ARG_NOTIFICATION_FOR) && getIntent().hasExtra(MyFirebaseMessagingService.ARG_SENDER_ID))
        {
            int notificationFor = getIntent().getIntExtra(MyFirebaseMessagingService.ARG_NOTIFICATION_FOR, 0);
            senderId = getIntent().getIntExtra(MyFirebaseMessagingService.ARG_SENDER_ID, 0);
            senderName = getIntent().getStringExtra(MyFirebaseMessagingService.ARG_SENDER_NAME);

            if(notificationFor == AppConst.NOTIFICATION_FOR_CHAT_SCREEN) {
                selectItem(2);
                return;
            }

        }else  if (getIntent().hasExtra("chat") && getIntent().hasExtra(MyFirebaseMessagingService.ARG_SENDER_ID)){
            senderId = getIntent().getIntExtra(MyFirebaseMessagingService.ARG_SENDER_ID, 0);
            senderName = getIntent().getStringExtra(MyFirebaseMessagingService.ARG_SENDER_NAME);
            selectItem(2);
        }else if(getIntent().hasExtra("upcoming") && !role.equals(getString(R.string.role_patient))){
            selectItem(1);
        }else if(getIntent().getAction()!=null){
            if(getIntent().getAction().equals("settings"))
                selectItem(list.size()-1);
            else if(getIntent().getAction().equals("appointment"))
                selectItem(1);
            else
                selectItem(0);
        }else{
            senderId=0;
            selectItem(0);
        }
        updateFcm();
    }

    @Override
    protected void onResume() {
        super.onResume();
        registerReceiver(broadcastReceiver, new IntentFilter(MyFirebaseMessagingService.ARG_CHAT_MESSAGE_RECEIVED));
    }

    public ArrayList<DrawerPojo> getDummyList() {
        list.clear();
        if(role.equals(getString(R.string.role_patient)))
            list.add(new DrawerPojo(0, "",getString(R.string.item_home),R.drawable.ic_home));
        list.add(new DrawerPojo(1, "",getString(R.string.item_appointment),R.drawable.ic_appointment));
        if(!role.equals(getString(R.string.role_patient)))
            list.add(new DrawerPojo(2, "",getString(R.string.item_upcoming),R.drawable.ic_appointment));
        list.add(new DrawerPojo(3,"",getString(R.string.item_messages),R.drawable.message));
        if(role.equals(getString(R.string.role_patient)))
            list.add(new DrawerPojo(4, "",getString(R.string.item_prescription),R.drawable.ic_prescription));
        list.add(new DrawerPojo(5, "",getString(R.string.item_health_blog),R.drawable.ic_health));
        list.add(new DrawerPojo(6, "",getString(R.string.item_profile),R.drawable.icon_user));
//        list.add(new DrawerPojo(7, "",getString(R.string.item_shop),R.drawable.ic_rating_us));
        list.add(new DrawerPojo(7, "",getString(R.string.item_rating),R.drawable.ic_rating_us));
        list.add(new DrawerPojo(8, "",getString(R.string.item_share),R.drawable.ic_share));
        list.add(new DrawerPojo(9, "",getString(R.string.item_settings),R.drawable.ic_settings));
        return list;
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        menu.clear();
        getMenuInflater().inflate(R.menu.menu_home, menu);
        if(M.getRole(context).equals(getString(R.string.role_patient))) {
            menu.findItem(R.id.item_location).setVisible(true);
        }else
            menu.findItem(R.id.item_location).setVisible(false);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onPrepareOptionsMenu(Menu menu) {
        return super.onPrepareOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (mDrawerToggle.onOptionsItemSelected(item)) {
            return true;
        }else if(item.getItemId()==R.id.item_location){
            gpsTracker=new GPSTracker(context);
            checkGpsPermission();
        }else if(item.getItemId()==R.id.item_notification){
            Intent it=new Intent(context,NotificationActivity.class);
            startActivity(it);
        }
        return super.onOptionsItemSelected(item);
    }

    private class DrawerItemClickListener implements
            ListView.OnItemClickListener {
        @Override
        public void onItemClick(AdapterView<?> parent, View view, int position,
                                long id) {
            if(position!=0) {
                selectItem(position-1);
            }
            mDrawerLayout.closeDrawer(mDrawerList);
        }
    }

    public void selectItem(int pos){
        Fragment fragment = null;
        fragmentposition=  pos;
        String item=list.get(pos).getText();
        String tag="";
        if(item.equals(getString(R.string.item_home))) {
            fragment = new SelectCategoryFragment();
            tag="SelectCategoryFragment";
        }else if(item.equals(getString(R.string.item_appointment))){
            tag="appointment";
            if(!role.equals(getString(R.string.role_patient)))
                fragment=new AppointmentFragment();
            else
                fragment=new Appointments();
        }else if(item.equals(getString(R.string.item_upcoming))){
            tag="upcomingappointment";
            fragment=new UpcomingFragment();
        }else if(item.equals(getString(R.string.item_prescription))){
            tag="history";
            fragment=new Prescription();
        }else if(item.equals(getString(R.string.item_rating))){
            final String appPackageName = getPackageName(); // getPackageName() from Context or Activity object
            try {
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=" + appPackageName)));
            } catch (android.content.ActivityNotFoundException anfe) {
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=" + appPackageName)));
            }
        }else if(item.equals(getString(R.string.item_share))){
            Intent sharingIntent = new Intent(Intent.ACTION_SEND);
            sharingIntent.setType("text/plain");
            sharingIntent.putExtra(android.content.Intent.EXTRA_TEXT,AppConst.share);
            startActivity(Intent.createChooser(sharingIntent, "Share using"));
        }else if(item.equals(getString(R.string.item_settings))) {
            tag="settings";
            fragment = new Settings();
        }else if(item.equals(getString(R.string.item_messages))) {
            tag="message";
            fragment = new MessageFragment();
            if(senderId>0){
                Bundle bundle = new Bundle();
                bundle.putInt(MyFirebaseMessagingService.ARG_SENDER_ID, senderId);
                bundle.putString(MyFirebaseMessagingService.ARG_SENDER_NAME, senderName);
                fragment.setArguments(bundle);
            }
        }else if(item.equals(getString(R.string.item_health_blog))) {
            tag="blog";
            fragment=new HealthBlogFragment();
        }else if(item.equals(getString(R.string.item_profile))) {
            tag="profile";
            if(!M.getRole(context).equals(getString(R.string.role_patient))) {
                Intent it = new Intent(context, DoctorProfile.class);
                startActivity(it);
            }else {
                Intent it = new Intent(context, EditProfile.class);
                startActivity(it);
            }
        }
//        else if(item.equals(getString(R.string.item_shop))) {
//
//        }

        if(fragment!=null) {
            FragmentManager fragmentManager = getSupportFragmentManager();
            FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
            fragmentTransaction.replace(R.id.content_frame, fragment,tag);
            if(pos!=0)
                fragmentTransaction.addToBackStack(tag);
            else
                fragmentTransaction.addToBackStack(null);
            fragmentTransaction.commit();
        }

        mDrawerLayout.closeDrawer(mDrawerList);
    }

    @Override
    public void setTitle(int titleId) {
        setTitle(getString(titleId));
    }

    @Override
    public void setTitle(CharSequence title) {
        mTitle = title;
        getSupportActionBar().setTitle(mTitle);
    }

    @Override
    protected void onPostCreate(Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);
        mDrawerToggle.syncState();
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        mDrawerToggle.onConfigurationChanged(newConfig);
    }

    @Override
    public void onBackPressed() {
        if (mDrawerLayout.isDrawerOpen(Gravity.LEFT)) {
            mDrawerLayout.closeDrawer(Gravity.LEFT);
        }else {
            FragmentManager fragmentManager = getSupportFragmentManager();
            String fragmentTag = fragmentManager.getBackStackEntryAt(fragmentManager.getBackStackEntryCount() - 1).getName();
            //Fragment currentFragment = fragmentManager.findFragmentByTag(fragmentTag);
            if(fragmentTag==null)
                finish();
            else
                super.onBackPressed();
        }
    }

    public void checkGpsPermission() {
        if (Build.VERSION.SDK_INT >= 23 &&
                ContextCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
                ContextCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
                ContextCompat.checkSelfPermission(this, android.Manifest.permission.WRITE_CALENDAR) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{android.Manifest.permission.ACCESS_FINE_LOCATION, android.Manifest.permission.ACCESS_COARSE_LOCATION, android.Manifest.permission.WRITE_CALENDAR},
                    MY_PERMISSIONS_REQUEST_LOCATION);
        } else {
            checkGpsStatus();
        }
    }

    private void checkGpsStatus() {
        try {
            if (!gpsTracker.canGetLocation()) {
                mGoogleApiClient = new GoogleApiClient.Builder(this)
                        .addApi(LocationServices.API)
                        .addConnectionCallbacks(this)
                        .addOnConnectionFailedListener(this).build();
                mGoogleApiClient.connect();
                locationRequest = LocationRequest.create();
                locationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);
                locationRequest.setInterval(30 * 1000);
                locationRequest.setFastestInterval(5 * 1000);
            } else {
                startHandler();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onConnected(@Nullable Bundle bundle) {
        try {
            LocationSettingsRequest.Builder builder = new LocationSettingsRequest.Builder()
                    .addLocationRequest(locationRequest);
            builder.setAlwaysShow(true);
            PendingResult<LocationSettingsResult> result =
                    LocationServices.SettingsApi.checkLocationSettings(
                            mGoogleApiClient,
                            builder.build()
                    );
            result.setResultCallback(this);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void startHandler() {
        M.showLoadingDialog(MainActivity.this);
        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {

            @Override
            public void run() {
                M.hideLoadingDialog();
                connectionDetector=new ConnectionDetector(context);
                if(!connectionDetector.isConnectingToInternet())
                {
                    Toast.makeText(context,"No Internet conntecion",Toast.LENGTH_SHORT).show();
                }else {
                    Intent it=new Intent(context,MapsActivity.class);
                    startActivity(it);
                }
            }

        }, 1000);
    }

    @Override
    public void onConnectionSuspended(int i) {
    }

    @Override
    public void onConnectionFailed(@NonNull ConnectionResult connectionResult) {
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == REQUEST_CHECK_SETTINGS) {
            if (resultCode == RESULT_OK) {
                startHandler();
            } else {
                Toast.makeText(MainActivity.this,"GPS not enabled", Toast.LENGTH_SHORT).show();
            }
        }
    }

    @Override
    public void onResult(@NonNull LocationSettingsResult locationSettingsResult) {
        final Status status = locationSettingsResult.getStatus();
        switch (status.getStatusCode()) {
            case LocationSettingsStatusCodes.SUCCESS:
                break;
            case LocationSettingsStatusCodes.RESOLUTION_REQUIRED:
                //  Location settings are not satisfied. Show the user a dialog
                try {
                    // Show the dialog by calling startResolutionForResult(), and check the result
                    // in onActivityResult().
                    status.startResolutionForResult(this, REQUEST_CHECK_SETTINGS);
                } catch (IntentSender.SendIntentException e) {
                    //failed to show
                }
                break;
            case LocationSettingsStatusCodes.SETTINGS_CHANGE_UNAVAILABLE:
                // Location settings are unavailable so not possible to show any dialog now
                break;
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        switch (requestCode) {
            case MY_PERMISSIONS_REQUEST_LOCATION:
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    checkGpsStatus();
                }
                break;
        }
    }

    private void updateFcm(){
        String fcmid="";
        if(AppConst.fcm_id==null){
            fcmid= FirebaseInstanceId.getInstance().getToken();
            if(fcmid==null)
                fcmid="";
        }else if(AppConst.fcm_id.length()<=0){
            fcmid= FirebaseInstanceId.getInstance().getToken();
            if(fcmid==null)
                fcmid="";
        }else{
            fcmid=AppConst.fcm_id;
        }
        if(fcmid.length()>0) {
            APIAuthentication mAuthenticationAPI = Service.createService(context, APIAuthentication.class);
            Call<SuccessPojo> call = mAuthenticationAPI.updateFcm(M.getID(context),M.getRole(context),fcmid);
            call.enqueue(new retrofit2.Callback<SuccessPojo>() {
                @Override
                public void onResponse(Call<SuccessPojo> call, Response<SuccessPojo> response) {
                    if (response.isSuccessful()) {
                        SuccessPojo pojo = response.body();
                    } else {
                        int statusCode = response.code();
                        ResponseBody errorBody = response.errorBody();
                    }
                }

                @Override
                public void onFailure(Call<SuccessPojo> call, Throwable t) {
                    Log.d("response:", "fail:" + t.getMessage());
                }
            });
        }
    }

    private void updateStatus(final String status) {

        M.showLoadingDialog(context);
        DoctorAPI mAuthenticationAPI = Service.createService(context,DoctorAPI.class);
        Call<SuccessPojo> call = mAuthenticationAPI.updateDrStaus(status,M.getID(context));
        call.enqueue(new retrofit2.Callback<SuccessPojo>() {
            @Override
            public void onResponse(Call<SuccessPojo> call, Response<SuccessPojo> response) {
                //Log.d("response:","data:"+response);
                if (response.isSuccessful()) {
                    SuccessPojo pojo = response.body();
                    if(pojo.getSuccess().equals("1")){
                        M.setStatus(status,context);
                    }
                    M.hideLoadingDialog();
                } else {
                    int statusCode = response.code();
                    M.hideLoadingDialog();
                    // handle request errors yourself
                    ResponseBody errorBody = response.errorBody();
                }
            }

            @Override
            public void onFailure(Call<SuccessPojo> call, Throwable t) {
                Log.d("response:","fail:"+t.getMessage());
                M.hideLoadingDialog();
                // handle execution failures like no internet connectivity
            }
        });
    }


    public  boolean isStoragePermissionGranted() {
        if (Build.VERSION.SDK_INT >= 23) {
            if (checkSelfPermission(android.Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) {

                return true;
            } else {
                ActivityCompat.requestPermissions(this, new String[]{android.Manifest.permission.WRITE_EXTERNAL_STORAGE, android.Manifest.permission.READ_EXTERNAL_STORAGE, android.Manifest.permission.ACCESS_FINE_LOCATION, android.Manifest.permission.ACCESS_COARSE_LOCATION}, 2);
                return false;
            }
        } else {
            return true;
        }
    }

    @Override
    public void onPause() {
        super.onPause();
        unregisterReceiver(broadcastReceiver);
    }


    private BroadcastReceiver broadcastReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {

            try {

                if(intent.getAction() == MyFirebaseMessagingService.ARG_CHAT_MESSAGE_RECEIVED)
                {
                    //Toast.makeText(context, "Broadcast Receiver Called !!!", Toast.LENGTH_SHORT).show();

                    String message_id = intent.getExtras().getString(MyFirebaseMessagingService.ARG_MESSAGE_ID);
                    String sender_id = intent.getExtras().getString(MyFirebaseMessagingService.ARG_SENDER_ID);
                    String receiver_id = intent.getExtras().getString(MyFirebaseMessagingService.ARG_RECEIVER_ID);
                    String message = intent.getExtras().getString(MyFirebaseMessagingService.ARG_MESSAGE);
                    String message_time = intent.getExtras().getString(MyFirebaseMessagingService.ARG_MESSAGE_TIME);
                    String sender_name = intent.getExtras().getString(MyFirebaseMessagingService.ARG_SENDER_NAME);
                    String sender_profile_pic = intent.getExtras().getString(MyFirebaseMessagingService.ARG_SENDER_PROFILE_PIC);

                    Message messageObj = new Message();
                    messageObj.setMessage_id(message_id);
                    messageObj.setSender_id(sender_id);
                    messageObj.setReceiver_id(receiver_id);
                    messageObj.setMessage(message);
                    messageObj.setTime(message_time);
                    messageObj.setSender_name(sender_name);
                    messageObj.setSender_profile_pic(sender_profile_pic);

                    dbHandler.addMessage(messageObj);

                    Fragment fragment =  getLastFragment();

                    if(fragment instanceof FragMessageCompose)
                    {
                        chatMessageListener = (ChatMessageReceived) fragment;
                        chatMessageListener.onChatMessageReceived();
                    }


                }
            }
            catch (Exception ex)
            {
                ex.printStackTrace();
            }

        }
    };

    public Fragment getLastFragment()
    {
        try {

            int totalBackStackEntry = getFragmentManager().getBackStackEntryCount();

            FragmentManager.BackStackEntry backStackEntry = (FragmentManager.BackStackEntry) getFragmentManager().getBackStackEntryAt(totalBackStackEntry - 1);

            Fragment targetFragment = getSupportFragmentManager().findFragmentByTag(backStackEntry.getName());

            return targetFragment;
        }
        catch (Exception ex)
        {
            ex.printStackTrace();
            return null;
        }
    }

}
