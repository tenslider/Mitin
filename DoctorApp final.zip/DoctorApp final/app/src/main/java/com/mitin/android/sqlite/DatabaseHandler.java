package com.mitin.android.sqlite;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import com.mitin.android.helper.AppConst;
import com.mitin.android.model.Message;

import java.util.ArrayList;
import java.util.List;


/**
 * Created by VBT-Android on 6/24/2017.
 */

public class DatabaseHandler extends SQLiteOpenHelper {

    // All Static variables
    // Database Version
    private static final int DATABASE_VERSION = 1;

    // Database Name
    private static final String DATABASE_NAME = AppConst.database_name;

    // Contacts table name
    private static final String TABLE_MESSAGES = "messages";

    // Contacts Table Columns names
    private static final String F_MESSAGE_ID = "message_id";
    private static final String F_MESSAGE = "message";
    private static final String F_SENDER_ID = "sender_id";
    private static final String F_RECEIVER_ID = "receiver_id";
    private static final String F_SENDER_NAME = "sender_name";
    private static final String F_RECEIVER_NAME = "receiver_name";
    private static final String F_SENDER_PROFILE_PIC = "sender_profile_pic";
    private static final String F_RECEIVER_PROFILE_PIC = "receiver_profile_pic";
    private static final String F_SEND_BY = "send_by";
    private static final String F_MESSAGE_TIME = "message_time";

    public DatabaseHandler(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    // Creating Tables
    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_CONTACTS_TABLE = "CREATE TABLE " + TABLE_MESSAGES + "("
                + F_MESSAGE_ID + " NUMERIC PRIMARY KEY,"
                + F_MESSAGE + " TEXT,"
                + F_SENDER_ID + " Text,"
                + F_RECEIVER_ID + " Text,"
                + F_SENDER_NAME + " VARCHAR(100),"
                + F_RECEIVER_NAME + " VARCHAR(100),"
                + F_SENDER_PROFILE_PIC + " VARCHAR(200),"
                + F_RECEIVER_PROFILE_PIC + " VARCHAR(200),"
                + F_SEND_BY + " VARCHAR(20),"
                + F_MESSAGE_TIME + " DATETIME" + ")";
        db.execSQL(CREATE_CONTACTS_TABLE);
    }

    // Upgrading database
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Drop older table if existed
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_MESSAGES);

        // Create tables again
        onCreate(db);
    }

    /**
     * All CRUD(Create, Read, Update, Delete) Operations
     */
    // Adding new message
    public void addMessage(Message message) {
        try {
            SQLiteDatabase db = this.getWritableDatabase();

            String message_time = message.getTime() != null ? message.getTime().toString() : "";
Log.d("chat db:",message.getMessage_id()+" "+message.getMessage());
            ContentValues values = new ContentValues();
            values.put(F_MESSAGE_ID, message.getMessage_id());
            values.put(F_MESSAGE, message.getMessage());
            values.put(F_SENDER_ID, message.getSender_id());
            values.put(F_RECEIVER_ID, message.getReceiver_id());
            values.put(F_SENDER_NAME, message.getSender_name());
            values.put(F_RECEIVER_NAME, message.getReceiver_name());
            values.put(F_SENDER_PROFILE_PIC, message.getSender_profile_pic());
            values.put(F_RECEIVER_PROFILE_PIC, message.getReceiver_profile_pic());
            values.put(F_SEND_BY,  message.getSend_by());
            values.put(F_MESSAGE_TIME,  message_time);

            // Inserting Row
            db.insert(TABLE_MESSAGES, null, values);
            db.close(); // Closing database connection

            System.out.println("SOP Message Added.");
        }
        catch (Exception ex)
        {
            ex.printStackTrace();
        }
    }

    // Getting All Contacts
    public List<Message> getAllMessages(int userId) {
        try {
            List<Message> messageList = new ArrayList<Message>();
            // Select All Query
            String selectQuery = "SELECT  * FROM " + TABLE_MESSAGES + " WHERE " + F_SENDER_ID + " = " + userId + " OR " + F_RECEIVER_ID + " = " + userId;

            SQLiteDatabase db = this.getWritableDatabase();
            Cursor cursor = db.rawQuery(selectQuery, null);

            // looping through all rows and adding to list
            if (cursor.moveToFirst()) {
                do {
                    Message message = new Message();
                    message.setMessage_id(cursor.getString(cursor.getColumnIndex(F_MESSAGE_ID)));
                    message.setMessage(cursor.getString(cursor.getColumnIndex(F_MESSAGE)));
                    message.setSender_id(cursor.getString(cursor.getColumnIndex(F_SENDER_ID)));
                    message.setReceiver_id(cursor.getString(cursor.getColumnIndex(F_RECEIVER_ID)));
                    message.setSender_name(cursor.getString(cursor.getColumnIndex(F_SENDER_NAME)));
                    message.setReceiver_name(cursor.getString(cursor.getColumnIndex(F_RECEIVER_NAME)));
                    message.setSender_profile_pic(cursor.getString(cursor.getColumnIndex(F_SENDER_PROFILE_PIC)));
                    message.setReceiver_profile_pic(cursor.getString(cursor.getColumnIndex(F_RECEIVER_PROFILE_PIC)));
                    message.setSend_by(cursor.getString(cursor.getColumnIndex(F_SEND_BY)));
                    message.setTime(cursor.getString(cursor.getColumnIndex(F_MESSAGE_TIME)));

                    // Adding contact to list
                    messageList.add(message);
                } while (cursor.moveToNext());
            }

            // return message list
            return messageList;
        }
        catch (Exception ex)
        {
            ex.printStackTrace();
            return null;
        }
    }

    // Getting All Contacts
    public List<Message> getAllMessages(int userId, long messageId) {
        try {
            List<Message> messageList = new ArrayList<Message>();
            // Select All Query
            String selectQuery = "SELECT  * FROM " + TABLE_MESSAGES + " WHERE (" + F_SENDER_ID + " = " + userId + " OR " + F_RECEIVER_ID + " = " + userId + ") AND " + F_MESSAGE_ID + " > "+messageId;

            SQLiteDatabase db = this.getWritableDatabase();
            Cursor cursor = db.rawQuery(selectQuery, null);

            // looping through all rows and adding to list
            if (cursor.moveToFirst()) {
                do {
                    Message message = new Message();
                    Log.d("message",cursor.getString(cursor.getColumnIndex(F_MESSAGE)));
                    message.setMessage_id(cursor.getString(cursor.getColumnIndex(F_MESSAGE_ID)));
                    message.setMessage(cursor.getString(cursor.getColumnIndex(F_MESSAGE)));
                    message.setSender_id(cursor.getString(cursor.getColumnIndex(F_SENDER_ID)));
                    message.setReceiver_id(cursor.getString(cursor.getColumnIndex(F_RECEIVER_ID)));
                    message.setSender_name(cursor.getString(cursor.getColumnIndex(F_SENDER_NAME)));
                    message.setReceiver_name(cursor.getString(cursor.getColumnIndex(F_RECEIVER_NAME)));
                    message.setSender_profile_pic(cursor.getString(cursor.getColumnIndex(F_SENDER_PROFILE_PIC)));
                    message.setReceiver_profile_pic(cursor.getString(cursor.getColumnIndex(F_RECEIVER_PROFILE_PIC)));
                    message.setSend_by(cursor.getString(cursor.getColumnIndex(F_SEND_BY)));
                    message.setTime(cursor.getString(cursor.getColumnIndex(F_MESSAGE_TIME)));

                    // Adding contact to list
                    messageList.add(message);
                } while (cursor.moveToNext());
            }

            // return message list
            return messageList;
        }
        catch (Exception ex)
        {
            ex.printStackTrace();
            return null;
        }
    }


    // Getting messages Count
    public int getMessageCount() {
        String countQuery = "SELECT  * FROM " + TABLE_MESSAGES;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(countQuery, null);
        cursor.close();

        // return count
        return cursor.getCount();
    }

}