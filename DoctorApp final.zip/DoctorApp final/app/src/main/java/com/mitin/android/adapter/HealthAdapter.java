package com.mitin.android.adapter;

import android.content.Context;
import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.github.curioustechizen.ago.RelativeTimeTextView;
import com.mitin.android.AppointmentDetail;
import com.mitin.android.R;
import com.mitin.android.helper.AppConst;
import com.mitin.android.model.BlogPojo;
import com.mitin.android.model.BlogPojo;
import com.mitin.android.view.CropSquareTransformation;
import com.squareup.picasso.Picasso;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;


public class HealthAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private static final int TYPE_ITEM = 1;
    private List<BlogPojo> list;
    Context context;
    String TAG="HealthAdapter";
    SimpleDateFormat defaultfmt=new SimpleDateFormat("yyyy-MM-dd HH:mm");
    SimpleDateFormat dtfmt=new SimpleDateFormat("dd MMM yyyy, hh:mm a");

    public HealthAdapter(List<BlogPojo> list, Context mcontext) {
        context = mcontext;
        this.list = list;
    }

    @Override
    public int getItemViewType(int position) {
        return TYPE_ITEM;
    }


    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.health_row, parent, false);
        return new ViewHolderPosts(view);
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {

        final BlogPojo model=list.get(position);
        final ViewHolderPosts itemview = (ViewHolderPosts) holder;

        itemview.tvtitle.setText(model.getTitle());

        String note=model.getDescription();
        if(note!=null){
            if(note.trim().length()>0) {
                itemview.tvdesc.setVisibility(View.VISIBLE);
                itemview.tvdesc.setText(note);
            }else
                itemview.tvdesc.setVisibility(View.GONE);
        }else{
            itemview.tvdesc.setVisibility(View.GONE);
        }
        String pic=model.getImage_name();
        if(pic==null)
            pic="";
        if(pic.trim().length()>0){
            itemview.iv.setVisibility(View.VISIBLE);
            Picasso.with(context)
                    .load(AppConst.blog_img_url + pic)
                    .transform(new CropSquareTransformation())
                    .placeholder(R.drawable.default_image)
                    .error(R.drawable.default_image)
                    .into(itemview.iv);
        }else
            itemview.iv.setVisibility(View.GONE);


    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public int getItemCount() {

        return list.size();

    }

    public class ViewHolderPosts extends RecyclerView.ViewHolder {
        TextView tvtitle,tvdesc;
        ImageView iv;

        public ViewHolderPosts(View itemView) {
            super(itemView);
            tvtitle = (TextView) itemView.findViewById(R.id.tvtitle);
            tvtitle.setTypeface(AppConst.font_regular(context));
            tvdesc = (TextView) itemView.findViewById(R.id.tvdesc);
            tvdesc.setTypeface(AppConst.font_regular(context));
            iv = (ImageView) itemView.findViewById(R.id.iv);
        }

    }

}
