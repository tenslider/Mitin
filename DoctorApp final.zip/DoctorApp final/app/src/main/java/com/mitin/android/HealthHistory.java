package com.mitin.android;

import android.content.Context;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

import com.mitin.android.adapter.PrescriptionAdapter;
import com.mitin.android.helper.AppConst;
import com.mitin.android.model.M;
import com.mitin.android.model.PrescriptionPojo;
import com.mitin.android.webservice.APIAuthentication;
import com.mitin.android.webservice.Service;

import java.util.List;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Response;

public class HealthHistory extends AppCompatActivity {

    Context context;
    String TAG="Prescription";
    RecyclerView rv;
    TextView tvnodata;
    PrescriptionAdapter adapter;
    String pid;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_health_history);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeButtonEnabled(true);
        context=HealthHistory.this;
        rv=(RecyclerView)findViewById(R.id.rv);
        rv.setLayoutManager(new LinearLayoutManager(context));
        rv.setHasFixedSize(true);
        tvnodata=(TextView)findViewById(R.id.tvnodata);
        tvnodata.setTypeface(AppConst.font_regular(context));

        if(getIntent().getExtras()!=null){
            pid=getIntent().getStringExtra("id");
        }
        getData();
    }

    private void getData() {

        M.showLoadingDialog(context);
        APIAuthentication mAuthenticationAPI = Service.createService(context,APIAuthentication.class);
        Call<List<PrescriptionPojo>> call = mAuthenticationAPI.getPrescriptions(pid,M.getID(context));
        call.enqueue(new retrofit2.Callback<List<PrescriptionPojo>>() {
            @Override
            public void onResponse(Call<List<PrescriptionPojo>> call, Response<List<PrescriptionPojo>> response) {
                Log.d("response:","data:"+response);
                if (response.isSuccessful()) {
                    List<PrescriptionPojo> pojo = response.body();
                    if(pojo!=null && pojo.size()>0){
                        rv.setVisibility(View.VISIBLE);
                        tvnodata.setVisibility(View.GONE);
                        adapter=new PrescriptionAdapter(pojo,context);
                        rv.setAdapter(adapter);
                    }else{
                        rv.setVisibility(View.GONE);
                        tvnodata.setVisibility(View.VISIBLE);
                    }
                    M.hideLoadingDialog();
                } else {
                    int statusCode = response.code();
                    M.hideLoadingDialog();
                    ResponseBody errorBody = response.errorBody();
                }
            }

            @Override
            public void onFailure(Call<List<PrescriptionPojo>> call, Throwable t) {
                Log.d("response:","fail:"+t.getMessage());
                M.hideLoadingDialog();
            }
        });
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if(item.getItemId()==android.R.id.home)
            onBackPressed();
        return super.onOptionsItemSelected(item);
    }
}
