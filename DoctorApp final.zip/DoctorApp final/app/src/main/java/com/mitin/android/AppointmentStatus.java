package com.mitin.android;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.mitin.android.helper.AppConst;

import java.text.ParseException;
import java.text.SimpleDateFormat;

public class AppointmentStatus extends AppCompatActivity implements View.OnClickListener {

    TextView txt;
    Button btnhome;

    Context context;
    String TAG="AppointmentStatus";
    String dt,tm;
    SimpleDateFormat dfmt=new SimpleDateFormat("yyyy-MM-dd");
    SimpleDateFormat tfmt=new SimpleDateFormat("HH:mm:ss");
    SimpleDateFormat dtfmt=new SimpleDateFormat("dd MMM yyyy");
    SimpleDateFormat tmfmt=new SimpleDateFormat("HH:mm a");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_appointment_status);
        context=AppointmentStatus.this;
        if(getIntent().getExtras()!=null){
            dt=getIntent().getStringExtra("date");
            tm=getIntent().getStringExtra("time");
        }else{
            finish();
        }
        initview();

    }

    private void initview() {

        txt=(TextView)findViewById(R.id.txt1);
        txt.setTypeface(AppConst.font_regular(context));
        btnhome=(Button)findViewById(R.id.btnhome);
        btnhome.setTypeface(AppConst.font_semibold(context));
        String d="",t="";
        try {
            d=dtfmt.format(dfmt.parse(dt));
            t=tmfmt.format(tfmt.parse(tm));
            txt.setText("Gracias por usar Mitin.\nSu cita ha sido reservada con éxito para\n"+d+" "+t);
        } catch (ParseException e) {
            e.printStackTrace();
        }

        btnhome.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        if(v==btnhome)
            onBackPressed();
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        Intent it=new Intent(context,MainActivity.class);
        finish();
        startActivity(it);
    }
}
