package com.mitin.android.model;

/**
 * Created by SWIFT-3 on 07/07/17.
 */

public class CityPojo {

    String city;

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }
}
