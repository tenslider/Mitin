package com.mitin.android.model;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ChatUserPojo {

    private List<User_list> user_list = null;
    private Integer totalPages;
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    public List<User_list> getUser_list() {
        return user_list;
    }

    public void setUser_list(List<User_list> user_list) {
        this.user_list = user_list;
    }

    public Integer getTotalPages() {
        return totalPages;
    }

    public void setTotalPages(Integer totalPages) {
        this.totalPages = totalPages;
    }

    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}
