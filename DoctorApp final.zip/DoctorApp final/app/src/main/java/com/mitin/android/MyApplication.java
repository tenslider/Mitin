package com.mitin.android;

import android.app.Activity;
import android.app.Application;
import android.content.Intent;
import android.location.Location;
import android.util.Log;

import com.mitin.android.model.M;

/**
 * Created by keyur.belani on 8/31/2016.
 */
public class MyApplication extends Application {

    private static final String TAG = MyApplication.class.getSimpleName();

    private Location location;

    private boolean isInChatList;
    private int chatUserId = 0;

    @Override
    public void onCreate() {
        super.onCreate();
        Log.d(TAG, "onCreate");

        initSingletons();
    }

    private void initSingletons() {
        Log.d(TAG, "initSingletons");
    }


    public Location getLocation() {

        return location;
    }

    public void setLocation(Location location) {
        this.location = location;
    }

    public boolean isInChatList() {
        return isInChatList;
    }

    public void setInChatList(boolean inChatList) {
        isInChatList = inChatList;
    }

    public int getChatUserId() {
        return chatUserId;
    }

    public void setChatUserId(int chatUserId) {
        this.chatUserId = chatUserId;
    }

    public boolean logout(Activity activity) {
        Log.d(TAG, "logout");
        try
        {
            M.logOut(activity.getApplicationContext());

            Intent intent = new Intent(getApplicationContext(), LoginActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK|Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);

            return true;
        }
        catch(Exception ex)
        {
            ex.printStackTrace();
            return false;
        }
    }

}
