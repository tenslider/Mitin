package com.mitin.android.Doctor;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.mitin.android.HealthHistory;
import com.mitin.android.MainActivity;
import com.mitin.android.R;
import com.mitin.android.helper.AppConst;
import com.mitin.android.model.AppointmentPojo;
import com.mitin.android.model.M;
import com.mitin.android.model.SuccessPojo;
import com.mitin.android.view.CropSquareTransformation;
import com.mitin.android.webservice.DoctorAPI;
import com.mitin.android.webservice.Service;
import com.github.curioustechizen.ago.RelativeTimeTextView;
import com.squareup.picasso.Picasso;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class Detail extends AppCompatActivity implements View.OnClickListener {

    TextView tvname,tvnote,tvstatus,tvblood,tvheight,tvweight,tvcurr,tvchronic,btnpre;
    RelativeTimeTextView tvtime;
    ImageView iv;
    Button btncancel,btncomplete,btnaccept;

    String TAG="Detail",desc=null, diagnose, prognosis;
    Context context;
    AppointmentPojo model;
    SimpleDateFormat defaultfmt=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    SimpleDateFormat dtfmt=new SimpleDateFormat("dd MMM yyyy, HH:mm aa");
    Dialog dialog;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        model= AppConst.selAppointment;
        context=Detail.this;
        initview();
    }

    private void initview() {
        tvname = (TextView) findViewById(R.id.tvdrname);
        tvname.setTypeface(AppConst.font_regular(context));
        tvtime = (RelativeTimeTextView) findViewById(R.id.tvtime);
        tvtime.setTypeface(AppConst.font_regular(context));
        tvnote = (TextView) findViewById(R.id.tvnote);
        tvnote.setTypeface(AppConst.font_regular(context));
        tvstatus = (TextView) findViewById(R.id.tvstatus);
        tvstatus.setTypeface(AppConst.font_regular(context));
        tvblood = (TextView) findViewById(R.id.tvblood);
        tvblood.setTypeface(AppConst.font_regular(context));
        tvheight = (TextView) findViewById(R.id.tvheight);
        tvheight.setTypeface(AppConst.font_regular(context));
        tvweight = (TextView) findViewById(R.id.tvweight);
        tvweight.setTypeface(AppConst.font_regular(context));
        tvcurr = (TextView) findViewById(R.id.tvcurrhealth);
        tvcurr.setTypeface(AppConst.font_regular(context));
        tvchronic = (TextView) findViewById(R.id.tvchronic);
        tvchronic.setTypeface(AppConst.font_regular(context));
        iv = (ImageView) findViewById(R.id.ivdoctor);
        btncancel=(Button)findViewById(R.id.btncancel);
        btncancel.setTypeface(AppConst.font_semibold(context));
        btncancel.setOnClickListener(this);
        btncomplete=(Button)findViewById(R.id.btncomplete);
        btncomplete.setTypeface(AppConst.font_semibold(context));
        btncomplete.setOnClickListener(this);
        btnaccept=(Button)findViewById(R.id.btnaccept);
        btnaccept.setTypeface(AppConst.font_semibold(context));
        btnaccept.setOnClickListener(this);
        btnpre = (Button) findViewById(R.id.btnpre);
        btnpre.setTypeface(AppConst.font_semibold(context));
        btnpre.setOnClickListener(this);
        if(M.getType(context).equals(getString(R.string.role_doctor))) {
            btnpre.setVisibility(View.VISIBLE);
            tvheight.setVisibility(View.VISIBLE);
            tvweight.setVisibility(View.VISIBLE);
            tvchronic.setVisibility(View.VISIBLE);
            tvcurr.setVisibility(View.VISIBLE);
            tvblood.setVisibility(View.VISIBLE);
        }else{
            btnpre.setVisibility(View.GONE);
            tvheight.setVisibility(View.GONE);
            tvweight.setVisibility(View.GONE);
            tvchronic.setVisibility(View.GONE);
            tvcurr.setVisibility(View.GONE);
            tvblood.setVisibility(View.GONE);
        }
        tvname.setText(model.getName());
        String t=model.getAppointment_date()+" "+model.getAppointment_time();
        Date dt=null;
        try {
            dt=defaultfmt.parse(t);
            tvtime.setText(dtfmt.format(dt));
            //tvtime.setReferenceTime(dt.getTime());
        } catch (ParseException e) {
            e.printStackTrace();
        }

        String blood=model.getBlood_type();
        if(blood!=null){
            if(blood.trim().length()>0) {
                tvblood.setVisibility(View.VISIBLE);
                tvblood.setText(getString(R.string.blood_type)+" : "+blood);
            }else
                tvblood.setVisibility(View.GONE);
        }else{
            tvblood.setVisibility(View.GONE);
        }

        String he=model.getHeight();
        if(he!=null){
            if(he.trim().length()>0) {
                tvheight.setVisibility(View.VISIBLE);
                tvheight.setText(getString(R.string.height)+" : "+he);
            }else
                tvheight.setVisibility(View.GONE);
        }else{
            tvheight.setVisibility(View.GONE);
        }

        String wi=model.getWeight();
        if(wi!=null){
            if(wi.trim().length()>0) {
                tvweight.setVisibility(View.VISIBLE);
                tvweight.setText(getString(R.string.weight)+" : "+wi);
            }else
                tvweight.setVisibility(View.GONE);
        }else{
            tvweight.setVisibility(View.GONE);
        }

        String cuh=model.getCurrent_health_condition();
        if(cuh!=null){
            if(cuh.trim().length()>0) {
                tvcurr.setVisibility(View.VISIBLE);
                tvcurr.setText(getString(R.string.current_health_condition)+" : "+cuh);
            }else
                tvcurr.setVisibility(View.GONE);
        }else{
            tvcurr.setVisibility(View.GONE);
        }

        String ch=model.getCurrent_health_condition();
        if(ch!=null){
            if(ch.trim().length()>0) {
                tvchronic.setVisibility(View.VISIBLE);
                tvchronic.setText(getString(R.string.chronic_condition)+" : "+ch);
            }else
                tvchronic.setVisibility(View.GONE);
        }else{
            tvchronic.setVisibility(View.GONE);
        }

        String note=model.getNote();
        if(note!=null){
            if(note.trim().length()>0) {
                tvnote.setVisibility(View.VISIBLE);
                tvnote.setText(note);
            }else
                tvnote.setVisibility(View.GONE);
        }else{
            tvnote.setVisibility(View.GONE);
        }
        String pic=model.getPhoto();
        if(pic==null)
            pic="";
        if(pic.trim().length()>0){
            Picasso.with(context)
                    .load(AppConst.profile_img_url + pic)
                    .transform(new CropSquareTransformation())
                    .placeholder(R.drawable.ic_user)
                    .error(R.drawable.ic_user)
                    .into(iv);
        }

        String status=model.getAppointment_status();
        tvstatus.setVisibility(View.VISIBLE);
        tvstatus.setText(status);
        if(status.equals("pending")){
            btncancel.setVisibility(View.VISIBLE);
            btnaccept.setVisibility(View.VISIBLE);
            btncomplete.setVisibility(View.GONE);
            tvstatus.setTextColor(getResources().getColor(android.R.color.holo_blue_bright));
        }else if(status.equals("accepted")){
            btnaccept.setVisibility(View.GONE);
            btncancel.setVisibility(View.VISIBLE);
            btncomplete.setVisibility(View.VISIBLE);
            tvstatus.setTextColor(getResources().getColor(android.R.color.holo_green_light));
        }else{
            btnaccept.setVisibility(View.GONE);
            btncancel.setVisibility(View.GONE);
            btncomplete.setVisibility(View.GONE);
            tvstatus.setTextColor(getResources().getColor(android.R.color.holo_green_dark));
        }
    }

    @Override
    public void onClick(View v) {
        if(v==btncancel){
            desc=null;
            updateStatus(AppConst.status_cancel);
        }else if(v==btncomplete){
            if(M.getType(context).equals(getString(R.string.role_doctor))) {
                dialog = new Dialog(this, android.R.style.Theme_Black_NoTitleBar_Fullscreen);
                dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
                dialog.getWindow().setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT);
                dialog.setCancelable(true);
                dialog.getWindow().setContentView(R.layout.dialog_status_complete);

                final EditText etdesc = (EditText) dialog.findViewById(R.id.etdesc);
                final EditText etdiagnose = (EditText) dialog.findViewById(R.id.etdiagnose);
                final EditText etprognosis = (EditText) dialog.findViewById(R.id.etprognosis);
                Button btnsubmit = (Button) dialog.findViewById(R.id.btnsubmit);

                btnsubmit.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (etdesc.getText().toString().trim().length() <= 0)
                            desc = "";
                        else
                            desc = etdesc.getText().toString();
                        if (etdiagnose.getText().toString().trim().length() <= 0)
                            diagnose = "";
                        else
                            diagnose = etdiagnose.getText().toString();
                        if (etprognosis.getText().toString().trim().length() <= 0)
                            prognosis = "";
                        else
                            prognosis = etdesc.getText().toString();
                        dialog.dismiss();
                        updateStatus(AppConst.status_complete);

                    }
                });

                dialog.show();
            }else{
                updateStatus(AppConst.status_complete);
            }
        }else if(v==btnaccept){
            desc=null;
            updateStatus(AppConst.status_accept);
        }else if(v==btnpre){
            Intent it=new Intent(context, HealthHistory.class);
            it.putExtra("id",model.getPatient_id());
            startActivity(it);
        }
    }

    private void updateStatus(final String status){
        String type = "";



        M.showLoadingDialog(context);
        DoctorAPI mAuthenticationAPI = Service.createService(context,DoctorAPI.class);
        Call<SuccessPojo> call = mAuthenticationAPI.updateStatus(M.getID(context),model.getId(),status, diagnose, prognosis,desc, type);
        call.enqueue(new Callback<SuccessPojo>() {
            @Override
            public void onResponse(Call<SuccessPojo> call, Response<SuccessPojo> response) {
                Log.d("response:","data:"+response);
                if (response.isSuccessful()) {
                    SuccessPojo pojo=response.body();
                    if(pojo.getSuccess().equals("1")){
                        if(AppConst.status_complete.equals(status)){
                            Toast.makeText(context, R.string.appointment_complete_msg,Toast.LENGTH_SHORT).show();
                        }else if(AppConst.status_accept.equals(status)){
                            Toast.makeText(context, R.string.appointment_accept_msg,Toast.LENGTH_SHORT).show();
                        }else if(AppConst.status_cancel.equals(status)){
                            Toast.makeText(context, R.string.appointment_cancel_msg,Toast.LENGTH_SHORT).show();
                        }
                        Intent it=new Intent(context, MainActivity.class);
                        finish();
                        startActivity(it);
                    }else{

                    }

                } else {
                    int statusCode = response.code();
                    ResponseBody errorBody = response.errorBody();
                    Log.d(TAG,"error:"+statusCode+" "+errorBody);
                }
                M.hideLoadingDialog();
            }

            @Override
            public void onFailure(Call<SuccessPojo> call, Throwable t) {
                Log.d("response:","fail:"+t.getMessage());
                M.hideLoadingDialog();
            }
        });
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if(item.getItemId()==android.R.id.home){
            onBackPressed();
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }

}
