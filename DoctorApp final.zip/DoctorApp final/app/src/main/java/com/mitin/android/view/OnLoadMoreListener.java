package com.mitin.android.view;

public interface OnLoadMoreListener {
	void onLoadMore();
}
