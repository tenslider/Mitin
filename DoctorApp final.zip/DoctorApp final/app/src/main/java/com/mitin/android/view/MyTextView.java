package com.mitin.android.view;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Typeface;
import android.util.AttributeSet;
import android.widget.TextView;

import com.mitin.android.R;
import com.mitin.android.helper.AppConst;


public class MyTextView extends TextView {

	public MyTextView(Context context) {
		super(context);
		if (isInEditMode()) return;
		parseAttributes(null);
	}

	public MyTextView(Context context, AttributeSet attrs) {
		super(context, attrs);
		if (isInEditMode()) return;
		parseAttributes(attrs);
	}

	public MyTextView(Context context, AttributeSet attrs, int defStyle) {
		super(context, attrs, defStyle);
		if (isInEditMode()) return;
		parseAttributes(attrs);
	}
	
	private void parseAttributes(AttributeSet attrs) {
		int typeface;
		if (attrs == null) { //Not created from xml
			typeface = My.font_regular;
		} else {
		    TypedArray values = getContext().obtainStyledAttributes(attrs, R.styleable.MyTextView);
		    typeface = values.getInt(R.styleable.MyTextView_typeface, My.font_regular);
		    values.recycle();
		}
	    setTypeface(getMy(typeface));
	}
	
	public void setMyTypeface(int typeface) {
	    setTypeface(getMy(typeface));
	}
	
	private Typeface getMy(int typeface) {
		return getMy(getContext(), typeface);
	}
	
	public static Typeface getMy(Context context, int typeface) {
		switch (typeface) {
			case My.font_regular:
				if (My.pRegular == null) {
					My.pRegular = AppConst.font_regular(context);
				}
				return My.pRegular;
			case My.font_light:
				if (My.pLight == null) {
					My.pLight = AppConst.font_light(context);
				}
				return My.pLight;
			case My.font_meduim:
				if (My.pMeduim == null) {
					My.pMeduim = AppConst.font_medium(context);
				}
				return My.pMeduim;
			case My.font_semi_bold:
				if (My.pSemiBold == null) {
					My.pSemiBold = AppConst.font_semibold(context);
				}
				return My.pSemiBold;
		}
		return My.pRegular;
	}
	
	public static class My {
		public static final int font_regular = 0;
		public static final int font_light = 1;
		public static final int font_meduim = 2;
		public static final int font_semi_bold = 3;

		private static Typeface pRegular;
		private static Typeface pLight;
		private static Typeface pMeduim;
		private static Typeface pSemiBold;
	}
}
