package com.mitin.android.model;

import java.util.HashMap;
import java.util.Map;

public class Clinic_image {

    private String id;
    private String doctor_id;
    private String image_name;
    Boolean isserver;
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getDoctor_id() {
        return doctor_id;
    }

    public void setDoctor_id(String doctor_id) {
        this.doctor_id = doctor_id;
    }

    public String getImage_name() {
        return image_name;
    }

    public void setImage_name(String image_name) {
        this.image_name = image_name;
    }

    public Boolean getIsserver() {
        return isserver;
    }

    public void setIsserver(Boolean isserver) {
        this.isserver = isserver;
    }

    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}