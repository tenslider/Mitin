package com.mitin.android;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.mitin.android.model.M;

public class SelectCategoryFragment extends Fragment implements View.OnClickListener {

    View view;
    ImageView lldoctor,lllawyer,llhair,llspa;
    TextView tv1;
    Context context;
    String TAG="SelectCategory";

    public SelectCategoryFragment() {
    }

    public static SelectCategoryFragment newInstance(String param1, String param2) {
        SelectCategoryFragment fragment = new SelectCategoryFragment();
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        view= inflater.inflate(R.layout.fragment_select_category, container, false);
        context=getActivity();
        MainActivity.ivheading.setVisibility(View.VISIBLE);
        MainActivity.tvheading.setVisibility(View.GONE);
        lldoctor=(ImageView) view.findViewById(R.id.lldoctor);
        llhair=(ImageView)view.findViewById(R.id.llhair);
        lllawyer=(ImageView)view.findViewById(R.id.lllawyer);
        llspa=(ImageView)view.findViewById(R.id.llspa);
        tv1=(TextView)view.findViewById(R.id.tv1);
        tv1.setText(getString(R.string.hello)+" "+ M.getUsername(context)+",");

        llhair.setOnClickListener(this);
        llspa.setOnClickListener(this);
        lldoctor.setOnClickListener(this);
        lllawyer.setOnClickListener(this);
        return view;
    }

    @Override
    public void onClick(View v) {
        if(v==lllawyer){
            Intent it=new Intent(context,DoctorList.class);
            it.putExtra("type",getString(R.string.role_Lawyer));
            startActivity(it);
        }else if(v==lldoctor){
            Fragment fragment=new SelectDepartment();
            FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
            FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
            fragmentTransaction.replace(R.id.content_frame, fragment);
            fragmentTransaction.addToBackStack(null);
            fragmentTransaction.commit();
        } if(v==llhair){
            Intent it=new Intent(context,DoctorList.class);
            it.putExtra("type",getString(R.string.role_Hair_Salon));
            startActivity(it);
        }else  if(v==llspa){
            Intent it=new Intent(context,DoctorList.class);
            it.putExtra("type",getString(R.string.role_spa));
            startActivity(it);
        }
    }
}
