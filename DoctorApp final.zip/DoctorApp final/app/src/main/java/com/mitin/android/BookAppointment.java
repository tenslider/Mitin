package com.mitin.android;

import android.app.DatePickerDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.graphics.Color;
import android.os.Build;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.mitin.android.chips.ChipCloud;
import com.mitin.android.chips.ChipListener;
import com.mitin.android.helper.AppConst;
import com.mitin.android.model.DoctorDetailPojo;
import com.mitin.android.model.M;
import com.mitin.android.model.SuccessPojo;
import com.mitin.android.model.TimingSlots;
import com.mitin.android.webservice.APIAuthentication;
import com.mitin.android.webservice.Service;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

import devs.mulham.horizontalcalendar.HorizontalCalendar;
import devs.mulham.horizontalcalendar.HorizontalCalendarListener;
import devs.mulham.horizontalcalendar.HorizontalCalendarView;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Response;

public class BookAppointment extends AppCompatActivity implements View.OnClickListener {

    EditText etnote;
    LinearLayout ll,lltime;
    TextView tvdoctor,tvnodoctor,tvtm,tvtime;
    Button btnbook;
    CalendarView calendarView;
    ChipCloud chipCloud;
    Context context;
    boolean isscroll = false;
    String TAG="BookAppointment",dt="",day="";
    DoctorDetailPojo dr;
    DatePickerDialog.OnDateSetListener d;
    SimpleDateFormat dtfmt=new SimpleDateFormat("yyyy-MM-dd");
    SimpleDateFormat dayfmt=new SimpleDateFormat("EEEE", Locale.ENGLISH);
    SimpleDateFormat tmfmt=new SimpleDateFormat("HH:mm a");
    SimpleDateFormat defaulttmfmt=new SimpleDateFormat("HH:mm:ss");
    String tm="",note="";
    String[] tlist=null;
    Dialog dialog;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        String languageToLoad  = "es"; // your language
        Locale locale = new Locale(languageToLoad);
        Locale.setDefault(locale);
        Configuration config = new Configuration();
        config.locale = locale;
        getBaseContext().getResources().updateConfiguration(config,
                getBaseContext().getResources().getDisplayMetrics());
        setContentView(R.layout.activity_book_appointment);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        context=BookAppointment.this;
        checkPermission();
        if(AppConst.selDoctor==null){
            finish();
        }else {
            dr=AppConst.selDoctor;
            initview();
        }

    }

    private void initview() {

        etnote=(EditText)findViewById(R.id.etnote);
        etnote.setTypeface(AppConst.font_regular(context));
        ll=(LinearLayout)findViewById(R.id.ll);
        ll.setVisibility(View.GONE);
        lltime=(LinearLayout)findViewById(R.id.lltime);
        tvdoctor=(TextView)findViewById(R.id.tvdoctor);
        tvdoctor.setTypeface(AppConst.font_regular(context));
//        tvnodoctor=(TextView)findViewById(R.id.tvnodoctor);
        btnbook=(Button)findViewById(R.id.btnbook);
        calendarView=(CalendarView)findViewById(R.id.calview);
        calendarView.setMinDate(Calendar.getInstance().getTimeInMillis());
        tvtime=(TextView)findViewById(R.id.tvtime);
        tvtm=(TextView)findViewById(R.id.tvtm);

        tvdoctor.setText(dr.getDoctor_name());

        btnbook.setOnClickListener(this);
        dt=dtfmt.format(new Date());
        try {
            day = dayfmt.format(dtfmt.parse(dt));
        } catch (ParseException e) {
            e.printStackTrace();
        }
        tm="";
        getTime();
        calendarView.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {
            @Override
            public void onSelectedDayChange(@NonNull CalendarView calendarView, int i, int i1, int i2) {
                try {
                    Calendar cal=Calendar.getInstance();
                    cal.set(Calendar.YEAR,i);
                    cal.set(Calendar.MONTH,i1);
                    cal.set(Calendar.DATE,i2);
                    dt = dtfmt.format(cal.getTime());
                    day = dayfmt.format(dtfmt.parse(dt));
                    tm = "";
                    getTime();
                } catch (ParseException e) {
                    e.printStackTrace();
                }
            }
        });
        lltime.setOnClickListener(this);
//        horizontalCalendar.setCalendarListener(new HorizontalCalendarListener() {
//            @Override
//            public void onDateSelected(final Date date, int position) {
//
//                if(!isscroll) {
//                    dt = dtfmt.format(date.getTime());
//                    day = dayfmt.format(date.getTime());
//                    tm = "";
//                    getTime();
//
//                }
//            }
//
//            @Override
//            public void onCalendarScroll(HorizontalCalendarView calendarView,
//                                         int dx, int dy) {
//
//
//                calendarView.addOnScrollListener(new RecyclerView.OnScrollListener() {
//                    @Override
//                    public void onScrollStateChanged(RecyclerView recyclerView, int newState) {
//                        super.onScrollStateChanged(recyclerView, newState);
//
//                        isscroll = true;
//                        Log.d("here...", "scroll----"+newState);
//                        if (newState == RecyclerView.SCROLL_STATE_IDLE) {
//
//                            isscroll = false;
//
//
//                        }
//
//                    }
//
//                    @Override
//                    public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
//                        super.onScrolled(recyclerView, dx, dy);
//                        isscroll = true;
//                    }
//                });
//            }
//
//            @Override
//            public boolean onDateLongClicked(Date date, int position) {
//                return true;
//            }
//        });
    }
//
    @Override
    public void onClick(View v) {
       if(v==btnbook){
           tm=tvtime.getText().toString();
            if(tm.trim().length()<=0){
                Toast.makeText(context,"Select Timing",Toast.LENGTH_SHORT).show();
            }else{
                if(etnote.getText().toString().length()<=0)
                    note="";
                else
                    note=etnote.getText().toString();
                try {
                    String t= defaulttmfmt.format(tmfmt.parse(tm));
                    book(dt,t);
                } catch (ParseException e) {
                    e.printStackTrace();
                }

            }
        }else if(lltime==v){
           dialog = new Dialog(context);
           dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
           dialog.getWindow().setLayout(LinearLayout.LayoutParams.MATCH_PARENT,
                   LinearLayout.LayoutParams.MATCH_PARENT);
           dialog.setCancelable(true);
           dialog.setContentView(R.layout.dialog_timing);
           chipCloud=(ChipCloud)dialog.findViewById(R.id.chip_cloud);
           Button btndone=(Button)dialog.findViewById(R.id.btndone);
           btndone.setTypeface(AppConst.font_semibold(context));
           btndone.setOnClickListener(this);
           Log.d(TAG,"size:"+tlist.length);
           if(tlist!=null && tlist.length>0)
                setchips(tlist);
           dialog.show();
       }else if(v.getId()==R.id.btndone){
           dialog.cancel();
       }
    }

    private void book(final String da, final String ti) {
        M.showLoadingDialog(context);
        APIAuthentication mAuthenticationAPI = Service.createService(context,APIAuthentication.class);
        Call<SuccessPojo> call = mAuthenticationAPI.bookAppointment(dr.getId(),da,ti,M.getID(context),note);
        call.enqueue(new retrofit2.Callback<SuccessPojo>() {
            @Override
            public void onResponse(Call<SuccessPojo> call, Response<SuccessPojo> response) {
                Log.d("response:","data:"+response);
                M.hideLoadingDialog();
                if (response.isSuccessful()) {
                    SuccessPojo pojo = response.body();

                    if(pojo.getSuccess().equals("1")){
                        Intent it=new Intent(context,AppointmentStatus.class);
                        it.putExtra("date",da);
                        it.putExtra("time",ti);
                        finish();
                        startActivity(it);
                    }else{

                    }

                } else {
                    int statusCode = response.code();
                    M.hideLoadingDialog();
                    ResponseBody errorBody = response.errorBody();
                }
            }

            @Override
            public void onFailure(Call<SuccessPojo> call, Throwable t) {
                Log.d("response:","fail:"+t.getMessage());
                M.hideLoadingDialog();
            }
        });
    }

    private void getTime() {
        Log.d(TAG,dr.getId()+" "+dt+" "+day);
        M.showLoadingDialog(context);
        APIAuthentication mAuthenticationAPI = Service.createService(context,APIAuthentication.class);
        Call<TimingSlots> call = mAuthenticationAPI.getTiming(dr.getId(),dt,day);
        call.enqueue(new retrofit2.Callback<TimingSlots>() {
            @Override
            public void onResponse(Call<TimingSlots> call, Response<TimingSlots> response) {
                Log.d(TAG,"data:"+response);
                if (response.isSuccessful()) {
                    TimingSlots pojo = response.body();
                    tlist=null;
                    if(pojo.getSuccess().equals("1")){
                        ll.setVisibility(View.VISIBLE);
                        btnbook.setVisibility(View.VISIBLE);
                        tvtm.setText(getString(R.string.time));
                        tvtime.setVisibility(View.VISIBLE);
                        lltime.setClickable(true);
                        String t=pojo.getTiming().split(",")[0];
                        try {
                            tvtime.setText(tmfmt.format(defaulttmfmt.parse(t)));
                        } catch (ParseException e) {
                            e.printStackTrace();
                        }
                        tvtm.setTextColor(getResources().getColor(R.color.textPrimary));
                        tlist=pojo.getTiming().split(",");
                        Log.d(TAG,"timelist size:"+tlist);
                    }else{
                        lltime.setClickable(false);
                        tvtm.setText("Doctor not avaliable");
                        tvtime.setVisibility(View.GONE);
                        tvtime.setText("");
                        tvtm.setTextColor(getResources().getColor(android.R.color.holo_red_light));
                        ll.setVisibility(View.VISIBLE);
                        btnbook.setVisibility(View.GONE);
                    }
                } else {
                    int statusCode = response.code();
                    ResponseBody errorBody = response.errorBody();
                }
                M.hideLoadingDialog();
            }

            @Override
            public void onFailure(Call<TimingSlots> call, Throwable t) {
                Log.d(TAG,"fail:"+t.getMessage());
                M.hideLoadingDialog();
            }
        });
    }

    public void setchips(final String[] list)
    {
        final ArrayList<String> wlist = new ArrayList<String>();
        String array[] = null;
        int sel=0,p=0;
        for(String word: list) {
            String w = word;
            Date d=null;
            try {
                d=defaulttmfmt.parse(w);
                String v=tmfmt.format(d);
                wlist.add(v);
                if(tvtime.getText().toString().equals(v))
                    sel=p;
                p++;
            } catch (ParseException e) {
                e.printStackTrace();
            }
        }
        String[] namesArr = new String[wlist.size()];
        for (int i = 0; i < wlist.size(); i++) {
            namesArr[i] = wlist.get(i);
        }
    if(wlist.size()>0) {
        new ChipCloud.Configure()
                .chipCloud(chipCloud)
                .selectedColor(Color.parseColor("#fcd736"))
                .selectedFontColor(Color.parseColor("#000000"))
                .deselectedColor(Color.parseColor("#e1e1e1"))
                .deselectedFontColor(Color.parseColor("#ffffff"))
                .selectTransitionMS(500)
                .deselectTransitionMS(250)
                .mode(ChipCloud.Mode.SINGLE)
                .labels(namesArr)
                .typeface(AppConst.font_regular(context))
                .allCaps(false)
                .gravity(ChipCloud.Gravity.CENTER)
                .textSize(getResources().getDimensionPixelSize(R.dimen.default_textsize))
                .verticalSpacing(getResources().getDimensionPixelSize(R.dimen.vertical_spacing))
                .minHorizontalSpacing(getResources().getDimensionPixelSize(R.dimen.min_horizontal_spacing))
                .chipListener(new ChipListener() {
                    @Override
                    public void chipSelected(int index) {
                        tm = wlist.get(index);
                        tvtime.setText(tm);
                    }

                    @Override
                    public void chipDeselected(int index) {
                        tm = wlist.get(0);
                        tvtime.setText(tm);
                    }
                })
                .build();

        chipCloud.setSelectedChip(sel);
    }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if(item.getItemId()==android.R.id.home){
            onBackPressed();
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }

    public void checkPermission() {
        if (Build.VERSION.SDK_INT >= 23 &&
                ContextCompat.checkSelfPermission(this, android.Manifest.permission.WRITE_CALENDAR) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{android.Manifest.permission.WRITE_CALENDAR},102);
        } else {
        }
    }
}
