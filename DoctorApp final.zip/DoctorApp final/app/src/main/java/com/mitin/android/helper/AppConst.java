package com.mitin.android.helper;

import android.content.Context;
import android.graphics.Typeface;
import android.util.Log;
import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;
import org.joda.time.format.DateTimeFormat;
import com.mitin.android.model.AppointmentPojo;
import com.mitin.android.model.DoctorDetailPojo;
import com.mitin.android.model.DoctorPojo;
import com.mitin.android.model.HospitalPojo;
import com.mitin.android.model.NotificationPojo;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.TimeZone;

public class AppConst {

    public static String TAG="DoctorApp";

    public static final String serverurl ="http://mitinrd.com/admin/";// "http://192.168.0.9/mitin/";//Replace your URL here...
    public static final String MAIN =serverurl+"webservice/";
    public static final String profile_img_url=serverurl+"upload/patient/";
    public static final String dept_img_url=serverurl+"upload/dept/";
    public static final String doctor_img_url=serverurl+"upload/doctor/";
    public static final String clinic_img_url=serverurl+"upload/clinic/";
    public static final String blog_img_url=serverurl+"upload/blogs/";

    public static final String database_name="MitinApp";

    public static String appurl = "https://play.google.com/store/apps/details?id=com.mitin.android";  // replace your package name here for share
    public static final int NOTIFICATION_FOR_CHAT_SCREEN = 1;
    public static String share = "You can download android from : "+appurl;
    public static int distance=10;
    public static String fcm_id="";

    public static DoctorDetailPojo selDoctor;
    public static DoctorPojo seldr;
    public static AppointmentPojo selAppointment;
    public static ArrayList<DoctorPojo> hospitalPojoArrayList;
    public static HospitalPojo selHospital;
    public static NotificationPojo selNotification;
    public static String status_accept="accepted" ,status_complete="completed",status_cancel="cancelled";

    public static Typeface font_light(Context context){
        return Typeface.createFromAsset(context.getAssets(), "Poppins-Light.ttf");
    }

    public static Typeface font_medium(Context context){
        return Typeface.createFromAsset(context.getAssets(), "Poppins-Medium.ttf");
    }

    public static Typeface font_regular(Context context){
        return Typeface.createFromAsset(context.getAssets(), "Poppins-Regular.ttf");
    }

    public static Typeface font_semibold(Context context){
        return Typeface.createFromAsset(context.getAssets(), "Poppins-SemiBold.ttf");
    }




}
