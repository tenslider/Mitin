package com.mitin.android;

import android.content.Context;
import android.content.Intent;
import android.content.IntentSender;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.MenuItem;
import android.widget.Toast;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.PendingResult;
import com.google.android.gms.common.api.ResultCallback;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.LocationSettingsRequest;
import com.google.android.gms.location.LocationSettingsResult;
import com.google.android.gms.location.LocationSettingsStatusCodes;
import com.mitin.android.adapter.DoctorAdapter;
import com.mitin.android.helper.ConnectionDetector;
import com.mitin.android.model.DoctorPojo;
import com.mitin.android.model.M;
import com.mitin.android.util.GPSTracker;
import com.mitin.android.webservice.APIAuthentication;
import com.mitin.android.webservice.Service;

import java.util.ArrayList;
import java.util.List;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Response;

public class DoctorList extends AppCompatActivity implements GoogleApiClient.ConnectionCallbacks, GoogleApiClient.OnConnectionFailedListener, ResultCallback<LocationSettingsResult> {

    RecyclerView rv;
    String TAG="DoctorList",city,department,type;
    Context context;
    DoctorAdapter adapter;
    ArrayList<DoctorPojo> list=new ArrayList<>();
    GPSTracker gpsTracker;
    ConnectionDetector connectionDetector;
    protected GoogleApiClient mGoogleApiClient;
    private final int MY_PERMISSIONS_REQUEST_LOCATION = 3;
    int REQUEST_CHECK_SETTINGS = 100;
    protected LocationRequest locationRequest;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_doctor_list);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        context=DoctorList.this;

        rv=(RecyclerView)findViewById(R.id.rvdoctors);
        rv.setLayoutManager(new LinearLayoutManager(context));
        rv.setHasFixedSize(true);

        if(getIntent().getStringExtra("type")!=null){
            type=getIntent().getStringExtra("type");
            getSupportActionBar().setTitle(type);
        }

        checkGpsPermission();

    }

    private void startHandler() {
        M.showLoadingDialog(context);
        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {

            @Override
            public void run() {
                M.hideLoadingDialog();
                connectionDetector=new ConnectionDetector(context);
                if(!connectionDetector.isConnectingToInternet())
                {
                    Toast.makeText(context,"No Internet conntecion",Toast.LENGTH_SHORT).show();
                }else {
                    if(M.getCity(context)!=null && type!=null && !type.equals(context.getString(R.string.role_doctor))) {
                        getOthers();
                    }else if(M.getCity(context)!=null && M.getDepartment(context)!=null) {
                        getDoctors();
                    }else
                        finish();
                }
            }

        }, 1000);
    }

    private void getDoctors() {
        city=M.getCity(context);
        department=M.getDepartment(context);
        Log.d("city---", city + "===department--"+department);

        M.showLoadingDialog(context);
        APIAuthentication mAuthenticationAPI = Service.createService(context,APIAuthentication.class);
        Call<List<DoctorPojo>> call = mAuthenticationAPI.getDoctors(city,department);
        call.enqueue(new retrofit2.Callback<List<DoctorPojo>>() {
            @Override
            public void onResponse(Call<List<DoctorPojo>> call, Response<List<DoctorPojo>> response) {
                Log.d("response:","data:"+response);
                if (response.isSuccessful()) {
                    List<DoctorPojo> pojo = response.body();
                    if(pojo.size()>0){
                       list= (ArrayList<DoctorPojo>) pojo;
                        if(list.size()>0){
                            adapter=new DoctorAdapter(list,context,"doctor");
                            rv.setAdapter(adapter);
                        }
                    }
                    M.hideLoadingDialog();
                } else {
                    int statusCode = response.code();
                    M.hideLoadingDialog();
                    ResponseBody errorBody = response.errorBody();
                }
            }

            @Override
            public void onFailure(Call<List<DoctorPojo>> call, Throwable t) {
                Log.d("response:","fail:"+t.getMessage());
                M.hideLoadingDialog();
            }
        });
    }

    private void getOthers() {
        city=M.getCity(context);
        department=M.getDepartment(context);
        Log.d(TAG,"city---"+ city + "===type--"+type);

        M.showLoadingDialog(context);
        APIAuthentication mAuthenticationAPI = Service.createService(context,APIAuthentication.class);
        Call<List<DoctorPojo>> call = mAuthenticationAPI.getOthers(city,type);
        call.enqueue(new retrofit2.Callback<List<DoctorPojo>>() {
            @Override
            public void onResponse(Call<List<DoctorPojo>> call, Response<List<DoctorPojo>> response) {
                Log.d(TAG,"data:"+response);
                if (response.isSuccessful()) {
                    List<DoctorPojo> pojo = response.body();
                    if(pojo.size()>0){
                        list= (ArrayList<DoctorPojo>) pojo;
                        if(list.size()>0){
                            adapter=new DoctorAdapter(list,context,"doctor");
                            rv.setAdapter(adapter);
                        }
                    }
                    M.hideLoadingDialog();
                } else {
                    int statusCode = response.code();
                    M.hideLoadingDialog();
                    ResponseBody errorBody = response.errorBody();
                    Log.d(TAG,"error:"+statusCode);
                }
            }

            @Override
            public void onFailure(Call<List<DoctorPojo>> call, Throwable t) {
                Log.d(TAG,"fail:"+t.getMessage());
                M.hideLoadingDialog();
            }
        });
    }

    public void checkGpsPermission() {
        if (Build.VERSION.SDK_INT >= 23 &&
                ContextCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
                ContextCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
                ContextCompat.checkSelfPermission(this, android.Manifest.permission.WRITE_CALENDAR) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{android.Manifest.permission.ACCESS_FINE_LOCATION, android.Manifest.permission.ACCESS_COARSE_LOCATION, android.Manifest.permission.WRITE_CALENDAR},
                    MY_PERMISSIONS_REQUEST_LOCATION);
        } else {
            gpsTracker=new GPSTracker(context);
            checkGpsStatus();
        }
    }

    private void checkGpsStatus() {
        try {
            if (!gpsTracker.canGetLocation()) {
                mGoogleApiClient = new GoogleApiClient.Builder(this)
                        .addApi(LocationServices.API)
                        .addConnectionCallbacks(this)
                        .addOnConnectionFailedListener(this).build();
                mGoogleApiClient.connect();
                locationRequest = LocationRequest.create();
                locationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);
                locationRequest.setInterval(30 * 1000);
                locationRequest.setFastestInterval(5 * 1000);
            } else {
                startHandler();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if(item.getItemId()==android.R.id.home)
            onBackPressed();
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }

    @Override
    public void onConnected(@Nullable Bundle bundle) {
        try {
            LocationSettingsRequest.Builder builder = new LocationSettingsRequest.Builder()
                    .addLocationRequest(locationRequest);
            builder.setAlwaysShow(true);
            PendingResult<LocationSettingsResult> result =
                    LocationServices.SettingsApi.checkLocationSettings(
                            mGoogleApiClient,
                            builder.build()
                    );
            result.setResultCallback(this);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onConnectionSuspended(int i) {
    }

    @Override
    public void onConnectionFailed(@NonNull ConnectionResult connectionResult) {
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == REQUEST_CHECK_SETTINGS) {
            startHandler();
        }
    }

    @Override
    public void onResult(@NonNull LocationSettingsResult locationSettingsResult) {
        final Status status = locationSettingsResult.getStatus();
        switch (status.getStatusCode()) {
            case LocationSettingsStatusCodes.SUCCESS:
                break;
            case LocationSettingsStatusCodes.RESOLUTION_REQUIRED:
                //  Location settings are not satisfied. Show the user a dialog
                try {
                    // Show the dialog by calling startResolutionForResult(), and check the result
                    // in onActivityResult().
                    status.startResolutionForResult(this, REQUEST_CHECK_SETTINGS);
                } catch (IntentSender.SendIntentException e) {
                    //failed to show
                }
                break;
            case LocationSettingsStatusCodes.SETTINGS_CHANGE_UNAVAILABLE:
                // Location settings are unavailable so not possible to show any dialog now
                break;
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        switch (requestCode) {
            case MY_PERMISSIONS_REQUEST_LOCATION:
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    gpsTracker=new GPSTracker(context);
                    checkGpsStatus();
                }
                break;
        }
    }
}
