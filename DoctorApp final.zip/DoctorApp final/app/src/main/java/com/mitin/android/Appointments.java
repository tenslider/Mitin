package com.mitin.android;

import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.mitin.android.adapter.AppointmentAdapter;
import com.mitin.android.helper.AppConst;
import com.mitin.android.model.AppointmentPojo;
import com.mitin.android.model.M;
import com.mitin.android.webservice.APIAuthentication;
import com.mitin.android.webservice.Service;

import java.util.List;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class Appointments extends Fragment {

    View view;
    RecyclerView rv;
    TextView tvnodata;
    
    Context context;
    String TAG="Appointments";
    AppointmentAdapter adapter;
    String type="";

    public Appointments() {

    }

    public static Appointments newInstance(String param1, String param2) {
        Appointments fragment = new Appointments();
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        view= inflater.inflate(R.layout.fragment_appointments, container, false);
        context=getActivity();
        
        tvnodata=(TextView)view.findViewById(R.id.tvnodata);
        tvnodata.setTypeface(AppConst.font_regular(context));
        rv=(RecyclerView)view.findViewById(R.id.rvappointment);
        rv.setLayoutManager(new LinearLayoutManager(context));
        rv.setHasFixedSize(true);
        
        getAppointments();
        return view;
    }

    private void getAppointments(){
        Log.d(TAG,M.getID(context)+" "+type);
        M.showLoadingDialog(context);
        APIAuthentication mAuthenticationAPI = Service.createService(context,APIAuthentication.class);
        Call<List<AppointmentPojo>> call = mAuthenticationAPI.getAppointments(M.getID(context),type);
        call.enqueue(new Callback<List<AppointmentPojo>>() {
            @Override
            public void onResponse(Call<List<AppointmentPojo>> call, Response<List<AppointmentPojo>> response) {
                Log.d(TAG,"data:"+response);
                if (response.isSuccessful()) {
                    List<AppointmentPojo> pojo=response.body();
                    if(pojo!=null && pojo.size()>0){
                        rv.setVisibility(View.VISIBLE);
                        tvnodata.setVisibility(View.GONE);
                        adapter=new AppointmentAdapter(pojo,context);
                        rv.setAdapter(adapter);
                    }else{
                        rv.setVisibility(View.GONE);
                        tvnodata.setVisibility(View.VISIBLE);
                    }

                } else {
                    int statusCode = response.code();
                    ResponseBody errorBody = response.errorBody();
                    Log.d(TAG,"error:"+statusCode+" "+errorBody);
                }
                M.hideLoadingDialog();
            }

            @Override
            public void onFailure(Call<List<AppointmentPojo>> call, Throwable t) {
                Log.d(TAG,"fail:"+t.getMessage());
                M.hideLoadingDialog();
            }
        });
    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        menu.clear();
        inflater.inflate(R.menu.menu_appointment,menu);
        super.onCreateOptionsMenu(menu, inflater);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if(item.getItemId()==R.id.item_all && type.trim().length()>0){
            type="";
            getAppointments();
        }else if(item.getItemId()==R.id.item_dr && !type.equals(getString(R.string.role_doctor))){
            type=getString(R.string.role_doctor);
            getAppointments();
        }else if(item.getItemId()==R.id.item_spa && !type.equals(getString(R.string.role_spa))){
            type=getString(R.string.role_spa);
            getAppointments();
        }else if(item.getItemId()==R.id.item_hs && !type.equals(getString(R.string.role_Hair_Salon))){
            type=getString(R.string.role_Hair_Salon);
            getAppointments();
        }else if(item.getItemId()==R.id.item_ly && !type.equals(getString(R.string.role_Lawyer))){
            type=getString(R.string.role_Lawyer);
            getAppointments();
        }
        return super.onOptionsItemSelected(item);
    }
}
