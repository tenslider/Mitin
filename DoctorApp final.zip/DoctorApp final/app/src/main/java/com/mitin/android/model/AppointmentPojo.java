package com.mitin.android.model;

import java.util.HashMap;
import java.util.Map;

public class AppointmentPojo {

    private String insurance_name;
    private String date_of_birth;
    private String cedula;
    private String policy_number;
    private String id;
    private String department_id;
    private String doctor_id;
    private String appointment_date;
    private String appointment_time;
    private String patient_id;
    String name,photo;//for Patient
    private String note;
    private String appointment_status;
    private String done_by;
    private String created_time;
    private String dept_name;
    private String dept_image;
    private String doctor_name;
    private String doctor_image;
    String blood_type,height,weight,current_health_condition,chronic_condition;
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getDepartment_id() {
        return department_id;
    }

    public void setDepartment_id(String department_id) {
        this.department_id = department_id;
    }

    public String getDoctor_id() {
        return doctor_id;
    }

    public void setDoctor_id(String doctor_id) {
        this.doctor_id = doctor_id;
    }

    public String getAppointment_date() {
        return appointment_date;
    }

    public void setAppointment_date(String appointment_date) {
        this.appointment_date = appointment_date;
    }

    public String getAppointment_time() {
        return appointment_time;
    }

    public void setAppointment_time(String appointment_time) {
        this.appointment_time = appointment_time;
    }

    public String getPatient_id() {
        return patient_id;
    }

    public void setPatient_id(String patient_id) {
        this.patient_id = patient_id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note;
    }

    public String getAppointment_status() {
        return appointment_status;
    }

    public void setAppointment_status(String appointment_status) {
        this.appointment_status = appointment_status;
    }

    public String getDone_by() {
        return done_by;
    }

    public void setDone_by(String done_by) {
        this.done_by = done_by;
    }

    public String getCreated_time() {
        return created_time;
    }

    public void setCreated_time(String created_time) {
        this.created_time = created_time;
    }

    public String getDept_name() {
        return dept_name;
    }

    public void setDept_name(String dept_name) {
        this.dept_name = dept_name;
    }

    public String getDept_image() {
        return dept_image;
    }

    public void setDept_image(String dept_image) {
        this.dept_image = dept_image;
    }

    public String getDoctor_name() {
        return doctor_name;
    }

    public void setDoctor_name(String doctor_name) {
        this.doctor_name = doctor_name;
    }

    public String getDoctor_image() {
        return doctor_image;
    }

    public void setDoctor_image(String doctor_image) {
        this.doctor_image = doctor_image;
    }

    public String getPhoto() {
        return photo;
    }

    public void setPhoto(String photo) {
        this.photo = photo;
    }

    public String getBlood_type() {
        return blood_type;
    }

    public String getHeight() {
        return height;
    }

    public String getWeight() {
        return weight;
    }

    public String getCurrent_health_condition() {
        return current_health_condition;
    }

    public String getChronic_condition() {
        return chronic_condition;
    }

    public String getInsurance_name() {
        return insurance_name;
    }

    public String getDate_of_birth() {
        return date_of_birth;
    }

    public String getCedula() {
        return cedula;
    }

    public String getPolicy_number() {
        return policy_number;
    }

    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}
