package com.mitin.android.model;

/**
 * Created by SWIFT-3 on 10/07/17.
 */

public class DepartmentPojo {

    String id,name,dept_image;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDept_image() {
        return dept_image;
    }
}
