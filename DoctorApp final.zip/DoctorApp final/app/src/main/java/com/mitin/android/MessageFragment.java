package com.mitin.android;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.google.gson.Gson;
import com.mitin.android.adapter.MessageUserAdapter;
import com.mitin.android.helper.AppConst;
import com.mitin.android.model.ChatUserPojo;
import com.mitin.android.model.M;
import com.mitin.android.model.User_list;
import com.mitin.android.view.OnLoadMoreListener;
import com.mitin.android.webservice.MessageAPI;
import com.mitin.android.webservice.Service;

import java.util.ArrayList;
import java.util.List;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Response;

public class MessageFragment extends Fragment implements MessageUserAdapter.OnRecordItemClick {

    View view;
    Context mContext;
    String TAG="MessageFragment";

    private RecyclerView recyclerView;
    private TextView tvNoRecords;

    private List<User_list> userList = new ArrayList<>();
    private MessageUserAdapter messageUserAdapter;

    private int senderId = 0;
    private int page = 1;
    private int totalPages = 0;
    public static String ARG_SENDER_ID = "sender_id";
    public static String ARG_SENDER_NAME = "sender_name";

    private BroadcastReceiver handleMessageReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            addReceivedMessage("");
        }
    };

    public MessageFragment() {
        // Required empty public constructor
    }

    public static MessageFragment newInstance() {
        MessageFragment fragment = new MessageFragment();
        //Bundle args = new Bundle();
        //fragment.setArguments(args);
        return fragment;
    }

    public static MessageFragment newInstance(int senderId,String name) {
        MessageFragment fragment = new MessageFragment();
        Bundle args = new Bundle();
        args.putInt(ARG_SENDER_ID, senderId);
        args.putString(ARG_SENDER_NAME, name);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);
        mContext = getActivity();

        if (getArguments() != null) {

            if(getArguments().containsKey(ARG_SENDER_ID))
            {
                senderId = getArguments().getInt(ARG_SENDER_ID);
                String name = getArguments().getString(ARG_SENDER_NAME);

                Fragment fragment = FragMessageCompose.newInstance(senderId,name);
                loadFragment(fragment, "FRAG_MESSAGE_COMPOSE");
            }
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,Bundle savedInstanceState) {
        view=inflater.inflate(R.layout.fragment_message, container, false);
      //  MainActivity.tvheading.setText("Messages");
        mContext=getActivity();
        init(view);
        return view;
    }

    private void init(View view)
    {
        try
        {
            recyclerView = (RecyclerView) view.findViewById(R.id.recyclerView);
            tvNoRecords = (TextView) view.findViewById(R.id.tvNoRecords);
            tvNoRecords.setTypeface(AppConst.font_regular(mContext));
            recyclerView.setHasFixedSize(true);
            recyclerView.setLayoutManager(new LinearLayoutManager(mContext));

            messageUserAdapter = new MessageUserAdapter(mContext, this, userList, recyclerView);
            recyclerView.setAdapter(messageUserAdapter);

            loadUserChatList(page);
        }
        catch (Exception ex)
        {
            ex.printStackTrace();
        }
    }

    /*Set No Recods Found*/
    private void setNoRecords()
    {
        try
        {
            tvNoRecords.setVisibility(View.VISIBLE);
            recyclerView.setVisibility(View.GONE);
        }
        catch (Exception ex)
        {
            ex.printStackTrace();
        }
    }

    /*
    Load Fragment
    */
    private void loadFragment(Fragment fragment, String fragmentTag) {
        try {
            FragmentTransaction ft = getFragmentManager().beginTransaction();
            ft.replace(R.id.content_frame, fragment, fragmentTag);
            ft.addToBackStack(fragmentTag);
            ft.commit();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    private void addReceivedMessage(String message)
    {
        try
        {
            //Toast.makeText(mContext, "Message : "+message, Toast.LENGTH_SHORT).show();
        }
        catch (Exception ex)
        {
            ex.printStackTrace();
        }
    }

    private void loadUserChatList(final int page) {
        Log.d(TAG,M.getID(mContext)+" "+page+" "+M.getRole(getActivity()));
        if(page==1)
            M.showLoadingDialog(mContext);
        MessageAPI mAuthenticationAPI = Service.createService(mContext,MessageAPI.class);
        Call<ChatUserPojo> call = mAuthenticationAPI.getUsers(M.getID(mContext),page+"",M.getRole(getActivity()));
        call.enqueue(new retrofit2.Callback<ChatUserPojo>() {
            @Override
            public void onResponse(Call<ChatUserPojo> call, Response<ChatUserPojo> response) {
                Log.d(TAG,"data:"+response);
                if (response.isSuccessful()) {
                    ChatUserPojo pojo=response.body();
                    if(pojo.getUser_list()!=null){
                        if(pojo.getUser_list().size()>0){
                            loadResultData(pojo);
                        }else{
                            setNoRecords();
                        }
                    }else{
                        setNoRecords();
                    }
                    if(page==1)
                        M.hideLoadingDialog();
                } else {
                    int statusCode = response.code();
                    ResponseBody errorBody = response.errorBody();
                    Log.d(TAG,"error:"+statusCode+" "+errorBody);
                    if(page==1)
                        M.hideLoadingDialog();
                }

            }

            @Override
            public void onFailure(Call<ChatUserPojo> call, Throwable t) {
                Log.d(TAG,"fail:"+t.getMessage());
                if(page==1)
                    M.hideLoadingDialog();
            }
        });
    }

    /*
	 * For Message Users
	 */
//    private void loadUserChatList(int page, boolean flagSilent) {
//        try {
//
//            //if (isValidParamsForUpdateAddressInfo()) {
//
//            if (UTILS.isNetworkAvailable(mContext)) {
//
//                JSONObject jsonObject = new JSONObject();
//                jsonObject.put(USER_ID, UserLogin.getInstance().getId());
//                jsonObject.put(PAGE, page);
//                jsonObject.put(TIMESTAMP, "2017-06-25 19:02:55");
//
//                System.out.println("SOP UserChat List Input : "+jsonObject);
//
//                VolleyJSONCaller volleyCaller = new VolleyJSONCaller(FragMessage.this, API.GET_USER_CHAT_LIST, jsonObject, Request.Method.POST, flagSilent);
//                volleyCaller.executeJsonRequest();
//            }
//            else
//            {
//                UTILS.handleValidation(mContext, mContext.getString(R.string.alertInternetConnection));
//            }
//            //}
//        }
//        catch (Exception ex)
//        {
//            ex.printStackTrace();
//        }
//    }
//
//    @Override
//    public void responseResult(Object result) {
//        try {
//
//            if (result != null && result instanceof MessageUserResponse) {
//                MessageUserResponse messageUserResponse = (MessageUserResponse) result;
//
//                if (messageUserResponse.getUsers() != null && messageUserResponse.getUsers().size() > 0) {
//
//                    loadResultData(messageUserResponse);
//
//                    /*
//                    userList.clear();
//                    userList.addAll(messageUserResponse.getUsers());
//                    messageUserAdapter.notifyDataSetChanged();
//
//                    if(userList != null && userList.size() > 0)
//                    {
//                        recyclerView.setVisibility(View.VISIBLE);
//                    }
//                    else {
//                        setNoRecords();
//                    }*/
//                }
//                else {
//
//                    if (messageUserResponse.getMessage() != null) {
//                        //UTILS.handleValidation(mContext, messageUserResponse.getMessage().toString());
//
//                        setNoRecords();
//                    }
//                }
//            }
//            /*
//            else if (result != null && result instanceof AddRemoveFavouriteResponse) {
//                AddRemoveFavouriteResponse addRemoveFavouriteResponse = (AddRemoveFavouriteResponse) result;
//
//                if (addRemoveFavouriteResponse.getSuccess() == SUCCESS_STATUS_CODE) {
//
//                    int position = userList.indexOf(item);
//                    userList.remove(position);
//
//                    favouriteUserAdapter.notifyItemRemoved(position);
//
//                    Toast.makeText(mContext, addRemoveFavouriteResponse.getMessage(), Toast.LENGTH_SHORT).show();
//                }
//                else {
//
//                    if (addRemoveFavouriteResponse.getMessage() != null) {
//                        UTILS.handleValidation(mContext, addRemoveFavouriteResponse.getMessage().toString());
//                    }
//                }
//            }
//            */
//        }
//        catch (Exception ex)
//        {
//            ex.printStackTrace();
//        }
//    }

    /*
    Load Result Data List
     */
    private void loadResultData(ChatUserPojo response)
    {
        try
        {
            if (page > 1) {
                userList.remove(userList.size() - 1);
                messageUserAdapter.notifyItemRemoved(userList.size());
            } else if (page == 1) {
                userList.clear();
                messageUserAdapter.notifyDataSetChanged();
            }

            totalPages = response.getTotalPages();

            userList.addAll(response.getUser_list());
            messageUserAdapter.notifyDataSetChanged();
            messageUserAdapter.setLoaded();

            if (userList.isEmpty()) {
                //recyclerView vAppointmentPending.setVisibility(View.GONE);
                //tvNoRecords.setVisibility(View.VISIBLE);

                setNoRecords();
            } else {
                recyclerView.setVisibility(View.VISIBLE);
                tvNoRecords.setVisibility(View.GONE);
            }

            messageUserAdapter.setOnLoadMoreListener(new OnLoadMoreListener() {
                @Override
                public void onLoadMore() {

                    //int totalPages = (totalRecords / pageSize) + ((totalRecords % pageSize) > 0 ? 1 : 0);

                    if (page < totalPages && totalPages > 0) {

                        userList.add(null);
                        messageUserAdapter.notifyItemInserted(userList.size() - 1);

                        page = page + 1;

                        // call webservice
                        loadUserChatList(page);

                    } else if (page == totalPages) {
                        if (userList.get(userList.size() - 1) == null) {
                            userList.remove(userList.size() - 1);
                            messageUserAdapter.notifyItemRemoved(userList.size());
                        }
                    }

                }
            });
        }
        catch (Exception ex)
        {
            ex.printStackTrace();
        }
    }


    @Override
    public void recordItemClick(User_list item) {

        String jsonObject = new Gson().toJson(item);

        loadFragment(FragMessageCompose.newInstance(jsonObject), "FRAG_MESSAGE_COMPOSE");
    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        super.onCreateOptionsMenu(menu, inflater);
      //  inflater.inflate(R.menu.menu_message,menu);
    }

}
