
package com.mitin.android.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

public class SearchUserResponse {

    @SerializedName("success")
    @Expose
    private Integer success;
    @SerializedName("message")
    @Expose
    private String message;
    @SerializedName("user")
    @Expose
    private List<User> users;
    @SerializedName("totalPages")
    @Expose
    private Integer totalPages;
    @SerializedName("headers")
    @Expose
    private Headers headers;

    public Integer getSuccess() {
        return success;
    }

    public void setSuccess(Integer success) {
        this.success = success;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public List<User> getUsers() {
        return users;
    }

    public void setUsers(List<User> users) {
        this.users = users;
    }

    public Integer getTotalPages() { return totalPages; }

    public void setTotalPages(Integer totalPages) { this.totalPages = totalPages; }

    public Headers getHeaders() {
        return headers;
    }

    public void setHeaders(Headers headers) {
        this.headers = headers;
    }

    public static class User {

        @SerializedName("id")
        @Expose
        private Integer id;
        @SerializedName("name")
        @Expose
        private String name;
        @SerializedName("email")
        @Expose
        private String email;
        @SerializedName("type")
        @Expose
        private String type;
        @SerializedName("password")
        @Expose
        private String password;
        @SerializedName("photo")
        @Expose
        private String photo;
        @SerializedName("login_type")
        @Expose
        private String loginType;
        @SerializedName("interested_in")
        @Expose
        private Integer interestedIn;
        @SerializedName("country_id")
        @Expose
        private Integer countryId;
        @SerializedName("state_id")
        @Expose
        private Integer stateId;
        @SerializedName("city_id")
        @Expose
        private Integer cityId;
        @SerializedName("date_of_birth")
        @Expose
        private String dateOfBirth;
        @SerializedName("gender")
        @Expose
        private String gender;
        @SerializedName("phone")
        @Expose
        private String phone;
        @SerializedName("education")
        @Expose
        private String education;
        @SerializedName("about_me")
        @Expose
        private String aboutMe;
        @SerializedName("looking_for")
        @Expose
        private Integer lookingFor;
        @SerializedName("under_age")
        @Expose
        private Integer underAge;
        @SerializedName("created_at")
        @Expose
        private String createdAt;
        @SerializedName("updated_at")
        @Expose
        private String updatedAt;
        @SerializedName("state_name")
        @Expose
        private String stateName;
        @SerializedName("country_name")
        @Expose
        private String countryName;
        @SerializedName("city_name")
        @Expose
        private String cityName;
        @SerializedName("is_favourite")
        @Expose
        private boolean is_favourite;

        public Integer getId() {
            return id;
        }

        public void setId(Integer id) {
            this.id = id;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getEmail() {
            return email;
        }

        public void setEmail(String email) {
            this.email = email;
        }

        public String getType() {
            return type;
        }

        public void setType(String type) {
            this.type = type;
        }

        public String getPassword() {
            return password;
        }

        public void setPassword(String password) {
            this.password = password;
        }

        public String getPhoto() {
            return photo;
        }

        public void setPhoto(String photo) {
            this.photo = photo;
        }

        public String getLoginType() {
            return loginType;
        }

        public void setLoginType(String loginType) {
            this.loginType = loginType;
        }

        public Integer getInterestedIn() {
            return interestedIn;
        }

        public void setInterestedIn(Integer interestedIn) {
            this.interestedIn = interestedIn;
        }

        public Integer getCountryId() {
            return countryId;
        }

        public void setCountryId(Integer countryId) {
            this.countryId = countryId;
        }

        public Integer getStateId() {
            return stateId;
        }

        public void setStateId(Integer stateId) {
            this.stateId = stateId;
        }

        public Integer getCityId() {
            return cityId;
        }

        public void setCityId(Integer cityId) {
            this.cityId = cityId;
        }

        public String getDateOfBirth() {
            return dateOfBirth;
        }

        public void setDateOfBirth(String dateOfBirth) {
            this.dateOfBirth = dateOfBirth;
        }

        public String getGender() {
            return gender;
        }

        public void setGender(String gender) {
            this.gender = gender;
        }

        public String getPhone() {
            return phone;
        }

        public void setPhone(String phone) {
            this.phone = phone;
        }

        public String getEducation() {
            return education;
        }

        public void setEducation(String education) {
            this.education = education;
        }

        public String getAboutMe() {
            return aboutMe;
        }

        public void setAboutMe(String aboutMe) {
            this.aboutMe = aboutMe;
        }

        public Integer getLookingFor() {
            return lookingFor;
        }

        public void setLookingFor(Integer lookingFor) {
            this.lookingFor = lookingFor;
        }

        public Integer getUnderAge() {
            return underAge;
        }

        public void setUnderAge(Integer underAge) {
            this.underAge = underAge;
        }

        public String getCreatedAt() {
            return createdAt;
        }

        public void setCreatedAt(String createdAt) {
            this.createdAt = createdAt;
        }

        public String getUpdatedAt() {
            return updatedAt;
        }

        public void setUpdatedAt(String updatedAt) {
            this.updatedAt = updatedAt;
        }

        public String getStateName() {
            return stateName;
        }

        public void setStateName(String stateName) {
            this.stateName = stateName;
        }

        public String getCountryName() {
            return countryName;
        }

        public void setCountryName(String countryName) {
            this.countryName = countryName;
        }

        public String getCityName() {
            return cityName;
        }

        public void setCityName(String cityName) {
            this.cityName = cityName;
        }

        public boolean is_favourite() {
            return is_favourite;
        }

        public void setIs_favourite(boolean is_favourite) {
            this.is_favourite = is_favourite;
        }
    }

    public class Headers {

        @SerializedName("Cache-Control")
        @Expose
        private String cacheControl;
        @SerializedName("Content-Type")
        @Expose
        private String contentType;
        @SerializedName("Date")
        @Expose
        private String date;
        @SerializedName("Server")
        @Expose
        private String server;
        @SerializedName("Set-Cookie")
        @Expose
        private String setCookie;
        @SerializedName("Transfer-Encoding")
        @Expose
        private String transferEncoding;
        @SerializedName("X-Android-Received-Millis")
        @Expose
        private String xAndroidReceivedMillis;
        @SerializedName("X-Android-Response-Source")
        @Expose
        private String xAndroidResponseSource;
        @SerializedName("X-Android-Selected-Protocol")
        @Expose
        private String xAndroidSelectedProtocol;
        @SerializedName("X-Android-Sent-Millis")
        @Expose
        private String xAndroidSentMillis;
        @SerializedName("X-Powered-By")
        @Expose
        private String xPoweredBy;

        public String getCacheControl() {
            return cacheControl;
        }

        public void setCacheControl(String cacheControl) {
            this.cacheControl = cacheControl;
        }

        public String getContentType() {
            return contentType;
        }

        public void setContentType(String contentType) {
            this.contentType = contentType;
        }

        public String getDate() {
            return date;
        }

        public void setDate(String date) {
            this.date = date;
        }

        public String getServer() {
            return server;
        }

        public void setServer(String server) {
            this.server = server;
        }

        public String getSetCookie() {
            return setCookie;
        }

        public void setSetCookie(String setCookie) {
            this.setCookie = setCookie;
        }

        public String getTransferEncoding() {
            return transferEncoding;
        }

        public void setTransferEncoding(String transferEncoding) {
            this.transferEncoding = transferEncoding;
        }

        public String getXAndroidReceivedMillis() {
            return xAndroidReceivedMillis;
        }

        public void setXAndroidReceivedMillis(String xAndroidReceivedMillis) {
            this.xAndroidReceivedMillis = xAndroidReceivedMillis;
        }

        public String getXAndroidResponseSource() {
            return xAndroidResponseSource;
        }

        public void setXAndroidResponseSource(String xAndroidResponseSource) {
            this.xAndroidResponseSource = xAndroidResponseSource;
        }

        public String getXAndroidSelectedProtocol() {
            return xAndroidSelectedProtocol;
        }

        public void setXAndroidSelectedProtocol(String xAndroidSelectedProtocol) {
            this.xAndroidSelectedProtocol = xAndroidSelectedProtocol;
        }

        public String getXAndroidSentMillis() {
            return xAndroidSentMillis;
        }

        public void setXAndroidSentMillis(String xAndroidSentMillis) {
            this.xAndroidSentMillis = xAndroidSentMillis;
        }

        public String getXPoweredBy() {
            return xPoweredBy;
        }

        public void setXPoweredBy(String xPoweredBy) {
            this.xPoweredBy = xPoweredBy;
        }

    }
}
