package com.mitin.android;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.mitin.android.adapter.HealthAdapter;
import com.mitin.android.model.BlogPojo;
import com.mitin.android.model.M;
import com.mitin.android.webservice.APIAuthentication;
import com.mitin.android.webservice.Service;

import java.util.List;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Response;

public class HealthBlogFragment extends Fragment {

    TextView tvnodata;
    RecyclerView rv;
    Context context;
    String TAG="HealthBlogFragment";
    View view;
    HealthAdapter adapter;

    public HealthBlogFragment() {

    }

    public static HealthBlogFragment newInstance(String param1, String param2) {
        HealthBlogFragment fragment = new HealthBlogFragment();
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        view= inflater.inflate(R.layout.fragment_health_blog, container, false);
        context=getActivity();
        tvnodata=(TextView)view.findViewById(R.id.tvnodata);
        rv=(RecyclerView)view.findViewById(R.id.rvlist);
        rv.setLayoutManager(new LinearLayoutManager(context));
        rv.setHasFixedSize(true);

        getData();
        return view;
    }

    private void getData() {

        M.showLoadingDialog(context);
        APIAuthentication mAuthenticationAPI = Service.createService(context,APIAuthentication.class);
        Call<List<BlogPojo>> call = mAuthenticationAPI.getBlogs();
        call.enqueue(new retrofit2.Callback<List<BlogPojo>>() {
            @Override
            public void onResponse(Call<List<BlogPojo>> call, Response<List<BlogPojo>> response) {
                Log.d("response:","data:"+response);
                // response.isSuccessful() is true if the response code is 2xx
                if (response.isSuccessful()) {
                    List<BlogPojo> pojo = response.body();
                    if(pojo!=null && pojo.size()>0){
                        rv.setVisibility(View.VISIBLE);
                        tvnodata.setVisibility(View.GONE);
                        adapter=new HealthAdapter(pojo,context);
                        rv.setAdapter(adapter);
                    }else{
                        rv.setVisibility(View.GONE);
                        tvnodata.setVisibility(View.VISIBLE);
                    }
                    M.hideLoadingDialog();
                } else {
                    int statusCode = response.code();
                    M.hideLoadingDialog();
                    // handle request errors yourself
                    ResponseBody errorBody = response.errorBody();
                }
            }

            @Override
            public void onFailure(Call<List<BlogPojo>> call, Throwable t) {
                Log.d("response:","fail:"+t.getMessage());
                M.hideLoadingDialog();
                // handle execution failures like no internet connectivity
            }
        });
    }

}
