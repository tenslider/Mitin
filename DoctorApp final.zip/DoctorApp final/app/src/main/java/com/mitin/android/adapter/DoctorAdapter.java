package com.mitin.android.adapter;

import android.content.Context;
import android.content.Intent;
import android.location.Location;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RatingBar;
import android.widget.TextView;

import com.mitin.android.DoctorDetail;
import com.mitin.android.PrescriptionDetail;
import com.mitin.android.R;
import com.mitin.android.helper.AppConst;
import com.mitin.android.model.DepartmentPojo;
import com.mitin.android.model.DoctorPojo;
import com.mitin.android.util.GPSTracker;
import com.mitin.android.view.CropSquareTransformation;
import com.squareup.picasso.Picasso;

import java.util.List;


public class DoctorAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private static final int TYPE_ITEM = 1;
    private List<DoctorPojo> list;
    Context context;
    String TAG="DoctorAdapter",screen;
    GPSTracker gpsTracker;

    public DoctorAdapter(List<DoctorPojo> list, Context mcontext,String screen) {
        context = mcontext;
        this.list = list;
        this.screen=screen;
        gpsTracker=new GPSTracker(context);
    }

    @Override
    public int getItemViewType(int position) {
        return TYPE_ITEM;
    }


    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.doctor_row, parent, false);
        return new ViewHolderPosts(view);
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {

        final DoctorPojo model=list.get(position);
        final ViewHolderPosts itemview = (ViewHolderPosts) holder;

        itemview.tvname.setText(model.getDoctor_name());
        if(model.getClinic_name().toString().trim().length()>0) {
            itemview.tvclinic.setVisibility(View.VISIBLE);
            itemview.tvclinic.setText(model.getClinic_name());
        }else{
            itemview.tvclinic.setVisibility(View.GONE);
        }
        if(model.getPersonal_phone()!=null){
            if(model.getPersonal_phone().trim().length()>0){
               itemview.tvphone.setVisibility(View.VISIBLE);
                itemview.tvphone.setText(model.getPersonal_phone());
            }else
            itemview.tvphone.setVisibility(View.GONE);
        }else
            itemview.tvphone.setVisibility(View.GONE);

        Picasso.with(context)
                .load(AppConst.doctor_img_url+model.getDoctor_image())
                .transform(new CropSquareTransformation())
                .placeholder(R.drawable.ic_user)
                .error(R.drawable.ic_user)
                .into(itemview.ivdoctor);

        itemview.lldoctor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(screen.equals("Prescription")){
                    Intent it=new Intent(context, PrescriptionDetail.class);
                    AppConst.seldr=model;
                    context.startActivity(it);
                }else {
                    Intent it = new Intent(context, DoctorDetail.class);
                    it.putExtra("doctorid", model.getId());
                    context.startActivity(it);
                }
            }
        });

        if(model.getDistance().trim().length()<=0){
            itemview.lldist.setVisibility(View.INVISIBLE);
            Log.d("latitude---", "gpsTracker.getLatitude()"+model.getLatitude());
            if(gpsTracker!=null && gpsTracker.getLocation()!=null && gpsTracker.getLatitude()!=0){
                if(gpsTracker.getLatitude()>0 && gpsTracker.getLongitude()>0){
                    if(model.getLatitude()!=null) {
                        Double slat = Double.valueOf(model.getLatitude());
                        Double slng = Double.valueOf(model.getLongitude());
                        if (slat != 0 && slng != 0) {
                            Location sl = new Location("");
                            sl.setLatitude(slat);
                            sl.setLongitude(slng);
                            Float d = sl.distanceTo(gpsTracker.getLocation());
                            String dist = String.format("%.2f", d);
                            itemview.lldist.setVisibility(View.VISIBLE);
                            itemview.tvdistance.setText(dist + " km");
                        }
                    }
                }
            }

        }else {
            itemview.lldist.setVisibility(View.VISIBLE);
            String dist = String.format("%.2f", Float.parseFloat(model.getDistance()));
            itemview.tvdistance.setText(dist + " km");
        }

        if(model.getOverall_rating()!=null) {
            Float rating=Float.parseFloat(model.getOverall_rating()+"");
            itemview.rb.setRating(rating);
        }else{
            itemview.rb.setRating(0);
        }

        if(model.getEducation_details().trim().length()<=0){
            itemview.lledu.setVisibility(View.GONE);
        }else{
            itemview.lledu.setVisibility(View.VISIBLE);
            itemview.tvedu.setText(model.getEducation_details());
        }

        if(model.getDepartment()==null){
            itemview.lldep.setVisibility(View.GONE);
        }else if(model.getDepartment().size()>0){
            itemview.lldep.setVisibility(View.VISIBLE);
            String dp="";
            for(DepartmentPojo d:model.getDepartment()){
                if(dp.length()<=0)
                    dp=d.getName();
                else
                    dp=dp+","+d.getName();
            }
            itemview.tvdep.setText(dp);
        }else{
            itemview.lldep.setVisibility(View.GONE);
        }

    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public class ViewHolderPosts extends RecyclerView.ViewHolder {
        TextView tvname,tvclinic,tvdistance,tvedu,tvdep,tvphone;
        ImageView ivdoctor;
        LinearLayout lldoctor,lledu,lldep,lldist;
        RatingBar rb;

        public ViewHolderPosts(View itemView) {
            super(itemView);
            tvname = (TextView) itemView.findViewById(R.id.tvname);
            tvname.setTypeface(AppConst.font_regular(context));
            tvclinic = (TextView) itemView.findViewById(R.id.tvclinic);
            tvclinic.setTypeface(AppConst.font_regular(context));
            ivdoctor=(ImageView)itemView.findViewById(R.id.ivdoctor);
            lldoctor=(LinearLayout)itemView.findViewById(R.id.lldoctor);
            lledu=(LinearLayout)itemView.findViewById(R.id.lledu);
            lldep=(LinearLayout)itemView.findViewById(R.id.lldept);
            lldist=(LinearLayout)itemView.findViewById(R.id.lldist);
            tvdistance=(TextView)itemView.findViewById(R.id.tvdistance);
            tvdistance.setTypeface(AppConst.font_regular(context));
            tvdep=(TextView)itemView.findViewById(R.id.tvdepartment);
            tvdep.setTypeface(AppConst.font_regular(context));
            tvedu=(TextView)itemView.findViewById(R.id.tveducation);
            tvedu.setTypeface(AppConst.font_regular(context));
            tvphone=(TextView)itemView.findViewById(R.id.tvphone);
            tvphone.setTypeface(AppConst.font_regular(context));
            rb=(RatingBar)itemView.findViewById(R.id.rb);
        }

    }

}
