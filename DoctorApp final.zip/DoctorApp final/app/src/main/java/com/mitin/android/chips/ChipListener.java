package com.mitin.android.chips;

public interface ChipListener {
    void chipSelected(int index);

    void chipDeselected(int index);
}
