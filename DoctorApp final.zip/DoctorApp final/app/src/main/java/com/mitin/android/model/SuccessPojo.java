package com.mitin.android.model;

/**
 * Created by SWIFT-3 on 10/07/17.
 */

public class SuccessPojo {

    String success;
    String lastInsertedId,timestamp;//only for chat

    public String getSuccess() {
        return success;
    }

    public String getLastInsertedId() {
        return lastInsertedId;
    }

    public void setLastInsertedId(String lastInsertedId) {
        this.lastInsertedId = lastInsertedId;
    }

    public String getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(String timestamp) {
        this.timestamp = timestamp;
    }
}
