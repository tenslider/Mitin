package com.mitin.android.model;

/**
 * Created by SWIFT-3 on 10/07/17.
 */

public class TimingSlots {

    String success,timing;

    public String getSuccess() {
        return success;
    }

    public void setSuccess(String success) {
        this.success = success;
    }

    public String getTiming() {
        return timing;
    }

    public void setTiming(String timing) {
        this.timing = timing;
    }
}
