package com.mitin.android.webservice;

import com.mitin.android.model.ChatUserPojo;
import com.mitin.android.model.GetMessagePojo;
import com.mitin.android.model.SuccessPojo;

import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.POST;

/**
 * Created by SWIFT-3 on 19/07/17.
 */

public interface MessageAPI {

    @FormUrlEncoded
    @POST("chat/get_user_chat_list.php")
    Call<ChatUserPojo> getUsers(
            @Field("user_id") String user_id,
            @Field("page") String page,
            @Field("role") String role
    );

    @FormUrlEncoded
    @POST("chat/send_message.php")
    Call<SuccessPojo> sendMessage(
            @Field("sender_id") String sender_id,
            @Field("receiver_id") String receiver_id,
            @Field("message") String message,
            @Field("send_by") String send_by
    );

    @FormUrlEncoded
    @POST("chat/get_message.php")
    Call<GetMessagePojo> getMessages(
            @Field("user_id") String user_id,
            @Field("logged_in_userid") String logged_in_userid,
            @Field("page") String page,
            @Field("timestamp") String timestamp,
            @Field("role") String role
    );
}
